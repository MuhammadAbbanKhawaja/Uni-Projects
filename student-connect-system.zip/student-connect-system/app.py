from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from sqlalchemy.testing.suite.test_reflection import users
from werkzeug.security import generate_password_hash, check_password_hash
import os
import uuid

from datetime import datetime, timedelta

# Import database
from models.database import db, StudentDB, FriendshipDB, MessageDB, StudySessionDB, ResourceDB, ConnectionDB
# Import data structures (still used for in-memory operations)
from data_structures.hash_map import HashMap
from data_structures.graph import Graph

# Import algorithms
from algorithms.search import search_students_by_name, search_students_by_course
from algorithms.sort import rank_matches, sort_sessions_by_date, sort_resources_by_date
from algorithms.graph_algorithms import suggest_connections
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
import os
import uuid
import random
import string
from datetime import datetime, timedelta

from models.database import db, StudentDB, FriendshipDB, MessageDB, StudySessionDB, ResourceDB, ConnectionDB, AnalyticsDB
from datetime import datetime, timedelta, date
import json

# Initialize Flask app
app = Flask(__name__)
app.jinja_env.globals.update(min=min, max=max)
app.secret_key = 'your-secret-key-change-this-in-production'

# Database configuration
import os
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(BASE_DIR, "student_connect.db")}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db.init_app(app)

# Create tables
with app.app_context():
    db.create_all()
    print("✅ Database tables created!")


# ==================== HELPER FUNCTIONS ====================

def get_all_students_dict():
    """Get all students as list of dictionaries"""
    students = StudentDB.query.all()
    return [s.to_dict() for s in students]


def get_student_hashmap():
    """Build HashMap from database"""
    hashmap = HashMap()
    students = StudentDB.query.all()
    for s in students:
        hashmap.insert(s.roll_number, s.to_dict())
    return hashmap


def get_connection_graph():
    """Build Graph from database"""
    graph = Graph()
    students = StudentDB.query.all()
    for s in students:
        graph.add_vertex(s.roll_number)

    connections = ConnectionDB.query.all()
    for c in connections:
        graph.add_edge(c.student1_roll, c.student2_roll,
                       weight={'shared_courses': c.shared_courses.split(',') if c.shared_courses else []})
    return graph


def update_course_connections(user_roll):
    """Update graph connections based on shared courses"""
    user = StudentDB.query.get(user_roll)
    user_courses = set(user.courses.split(',')) if user.courses else set()
    user_courses = {c.strip() for c in user_courses if c.strip()}

    # Remove old connections for this user
    ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).delete()

    # Create new connections with other students who share courses
    all_students = StudentDB.query.filter(StudentDB.roll_number != user_roll).all()

    for other in all_students:
        other_courses = set(other.courses.split(',')) if other.courses else set()
        other_courses = {c.strip() for c in other_courses if c.strip()}

        # Find shared courses
        shared = user_courses & other_courses

        # Only create connection if there are shared courses
        if shared:
            connection = ConnectionDB(
                student1_roll=user_roll,
                student2_roll=other.roll_number,
                shared_courses=','.join(shared)
            )
            db.session.add(connection)

    db.session.commit()


# ==================== ACHIEVEMENT BADGES ====================

def calculate_badges(user_roll):
    """Calculate achievement badges for a user"""
    student = StudentDB.query.get(user_roll)
    badges = []

    # Connection Badges
    connection_count = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).count()

    if connection_count >= 1:
        badges.append(
            {'name': 'First Connection', 'icon': '🤝', 'color': 'primary', 'desc': 'Made your first connection'})
    if connection_count >= 5:
        badges.append({'name': 'Networker', 'icon': '🌐', 'color': 'info', 'desc': 'Connected with 5+ students'})
    if connection_count >= 10:
        badges.append(
            {'name': 'Social Butterfly', 'icon': '🦋', 'color': 'success', 'desc': 'Connected with 10+ students'})

    # Friend Badges
    friend_count = FriendshipDB.query.filter_by(user_roll=user_roll).count()

    if friend_count >= 1:
        badges.append({'name': 'Friendly', 'icon': '👋', 'color': 'warning', 'desc': 'Added your first friend'})
    if friend_count >= 5:
        badges.append({'name': 'Popular', 'icon': '⭐', 'color': 'warning', 'desc': 'Made 5+ friends'})

    # Resource Badges
    resource_count = ResourceDB.query.filter_by(uploader_roll=user_roll).count()

    if resource_count >= 1:
        badges.append({'name': 'Contributor', 'icon': '📚', 'color': 'info', 'desc': 'Shared your first resource'})
    if resource_count >= 5:
        badges.append({'name': 'Resource Master', 'icon': '🎓', 'color': 'success', 'desc': 'Shared 5+ resources'})
    if resource_count >= 10:
        badges.append({'name': 'Knowledge Guru', 'icon': '🧠', 'color': 'danger', 'desc': 'Shared 10+ resources'})

    # Group Badges
    #groups_created = StudyGroupDB.query.filter_by(creator_roll=user_roll).count()
    #groups_joined = StudyGroupDB.query.filter(StudyGroupDB.members.contains(user_roll)).count()

    #if groups_created >= 1:
     #   badges.append({'name': 'Group Leader', 'icon': '👥', 'color': 'primary', 'desc': 'Created a study group'})
    #if groups_joined >= 3:
     #   badges.append({'name': 'Team Player', 'icon': '🤝', 'color': 'success', 'desc': 'Joined 3+ study groups'})

    # Session Badges
    sessions_created = StudySessionDB.query.filter_by(organizer_roll=user_roll).count()

    if sessions_created >= 1:
        badges.append({'name': 'Organizer', 'icon': '📅', 'color': 'info', 'desc': 'Organized a study session'})
    if sessions_created >= 5:
        badges.append({'name': 'Study Master', 'icon': '📖', 'color': 'warning', 'desc': 'Organized 5+ sessions'})

    # Message Badges
    messages_sent = MessageDB.query.filter_by(from_roll=user_roll).count()

    if messages_sent >= 1:
        badges.append({'name': 'Communicator', 'icon': '💬', 'color': 'primary', 'desc': 'Sent your first message'})
    if messages_sent >= 10:
        badges.append({'name': 'Chatterbox', 'icon': '💭', 'color': 'success', 'desc': 'Sent 10+ messages'})

    # Profile Completion Badge
    if student and student.bio and student.phone and student.courses and student.skills:
        badges.append({'name': 'Profile Pro', 'icon': '✨', 'color': 'danger', 'desc': 'Completed your profile'})

    return badges


# ==================== ANALYTICS TRACKING FUNCTIONS ====================

def track_activity(user_roll, activity_type, metadata=None):
        """Track user activity for analytics"""
        try:
            now = datetime.now()
            activity = AnalyticsDB(
                user_roll=user_roll,
                activity_type=activity_type,
                activity_date=now.date(),
                activity_hour=now.hour,
                activity_metadata=json.dumps(metadata) if metadata else ''  # ✅ FIXED
            )
            db.session.add(activity)
            db.session.commit()
        except Exception as e:
            print(f"Analytics tracking error: {e}")
            db.session.rollback()


def get_activity_heatmap(user_roll, days=90):
    """Get activity heatmap data for last N days"""
    end_date = date.today()
    start_date = end_date - timedelta(days=days)

    activities = AnalyticsDB.query.filter(
        AnalyticsDB.user_roll == user_roll,
        AnalyticsDB.activity_date >= start_date,
        AnalyticsDB.activity_date <= end_date
    ).all()

    # Count activities per day
    activity_counts = {}
    for activity in activities:
        date_str = activity.activity_date.isoformat()
        activity_counts[date_str] = activity_counts.get(date_str, 0) + 1

    # Generate heatmap data for all days
    heatmap_data = []
    current_date = start_date
    while current_date <= end_date:
        date_str = current_date.isoformat()
        count = activity_counts.get(date_str, 0)
        # Categorize into levels 0-4
        if count == 0:
            level = 0
        elif count <= 2:
            level = 1
        elif count <= 5:
            level = 2
        elif count <= 10:
            level = 3
        else:
            level = 4

        heatmap_data.append({'date': date_str, 'count': count, 'level': level})
        current_date += timedelta(days=1)

    return heatmap_data


def get_hourly_activity(user_roll, days=30):
    """Get hourly activity distribution for productivity chart"""
    start_date = datetime.now() - timedelta(days=days)

    activities = AnalyticsDB.query.filter(
        AnalyticsDB.user_roll == user_roll,
        AnalyticsDB.created_at >= start_date
    ).all()

    # Count activities per hour
    hourly_counts = {i: 0 for i in range(24)}
    for activity in activities:
        hourly_counts[activity.activity_hour] = hourly_counts.get(activity.activity_hour, 0) + 1

    # Get max count for normalization
    max_count = max(hourly_counts.values()) if hourly_counts.values() else 1

    # Normalize to percentage
    hourly_percentages = []
    for hour in range(24):
        percentage = (hourly_counts[hour] / max_count * 100) if max_count > 0 else 0
        hourly_percentages.append(int(percentage))
    print(f"DEBUG hourly_activity: {hourly_percentages}")
    return hourly_percentages


def calculate_network_strength(user_roll):
    """Calculate network strength score"""
    connections = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).count()

    resources = ResourceDB.query.filter_by(uploader_roll=user_roll).count()

    total_views = db.session.query(db.func.sum(ResourceDB.views)).filter(
        ResourceDB.uploader_roll == user_roll
    ).scalar() or 0

    score = (connections * 10) + (resources * 15) + (total_views * 0.5)
    return int(score)


def calculate_learning_velocity(user_roll):
    """Calculate learning velocity percentage"""
    resources = ResourceDB.query.filter_by(uploader_roll=user_roll).count()
    sessions = StudySessionDB.query.filter(StudySessionDB.participants.contains(user_roll)).count()

    velocity = (resources * 2.5 + sessions * 3)
    return int(min(velocity, 100))  # Cap at 100%


def calculate_collaboration_index(user_roll):
    """Calculate collaboration index"""
    sessions = StudySessionDB.query.filter(StudySessionDB.participants.contains(user_roll)).count()
    connections = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).count()

    index = (sessions * 15) + (connections * 5)
    return int(index)


def get_peak_activity_time(user_roll, days=30):
    """Get user's peak activity time"""
    start_date = datetime.now() - timedelta(days=days)

    activities = AnalyticsDB.query.filter(
        AnalyticsDB.user_roll == user_roll,
        AnalyticsDB.created_at >= start_date
    ).all()

    if not activities:
        return "8-10 PM"

    # Count activities per hour
    hourly_counts = {}
    for activity in activities:
        hourly_counts[activity.activity_hour] = hourly_counts.get(activity.activity_hour, 0) + 1

    # Find peak hour
    peak_hour = max(hourly_counts, key=hourly_counts.get) if hourly_counts else 20

    # Convert to time range
    start = peak_hour
    end = (peak_hour + 2) % 24

    def format_hour(h):
        if h == 0:
            return "12 AM"
        elif h < 12:
            return f"{h} AM"
        elif h == 12:
            return "12 PM"
        else:
            return f"{h - 12} PM"

    return f"{format_hour(start)}-{format_hour(end)}"


def calculate_session_attendance_rate(user_roll):
    """Calculate session attendance rate"""
    # Sessions user joined
    joined_sessions = StudySessionDB.query.filter(
        StudySessionDB.participants.contains(user_roll)
    ).count()

    # Sessions user created
    created_sessions = StudySessionDB.query.filter_by(organizer_roll=user_roll).count()

    total_sessions = joined_sessions + created_sessions

    if total_sessions == 0:
        return 0

    # Assume 85% attendance if they joined sessions
    return min(85 + (joined_sessions * 2), 100)


def calculate_avg_response_time(user_roll, days=30):
    """Calculate average message response time in hours"""
    start_date = datetime.now() - timedelta(days=days)

    # Get messages where user replied
    received_messages = MessageDB.query.filter(
        MessageDB.to_roll == user_roll,
        MessageDB.timestamp >= start_date
    ).all()

    if not received_messages:
        return "N/A"

    response_times = []

    for received_msg in received_messages:
        # Find next message from this user to the sender
        response = MessageDB.query.filter(
            MessageDB.from_roll == user_roll,
            MessageDB.to_roll == received_msg.from_roll,
            MessageDB.timestamp > received_msg.timestamp
        ).first()

        if response:
            time_diff = (response.timestamp - received_msg.timestamp).total_seconds() / 3600  # Convert to hours
            response_times.append(time_diff)

    if not response_times:
        return "N/A"

    avg_hours = sum(response_times) / len(response_times)

    # Format nicely
    if avg_hours < 1:
        return f"{int(avg_hours * 60)}m"
    elif avg_hours < 24:
        return f"{avg_hours:.1f}h"
    else:
        return f"{int(avg_hours / 24)}d"


def get_engagement_percentage(user_roll, days=30):
    """Calculate engagement percentage based on activity"""
    start_date = datetime.now() - timedelta(days=days)

    activities = AnalyticsDB.query.filter(
        AnalyticsDB.user_roll == user_roll,
        AnalyticsDB.created_at >= start_date
    ).count()

    # Calculate based on expected daily activity (assume 3 activities per day is 100%)
    expected_activities = days * 3
    percentage = min(int((activities / expected_activities) * 100), 100)

    return percentage if percentage > 0 else 0

# ==================== AUTHENTICATION ROUTES ====================

@app.route('/')
def index():
    if 'user_roll' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        roll_number = request.form.get('roll_number')
        password = request.form.get('password')

        student = StudentDB.query.get(roll_number)

        if student and student.password == password:
            session['user_roll'] = roll_number
            session['user_name'] = student.name
            track_activity(roll_number, 'login')
            flash('Login successful!', 'success')

            return redirect(url_for('dashboard'))
        else:
            flash('Invalid roll number or password', 'error')

    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        roll_number = request.form.get('roll_number')
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        department = request.form.get('department')
        semester = int(request.form.get('semester', 1))

        if StudentDB.query.get(roll_number):
            flash('Roll number already registered!', 'error')
            return render_template('signup.html')

        new_student = StudentDB(
            roll_number=roll_number,
            name=name,
            email=email,
            password=password,
            department=department,
            semester=semester
        )
        db.session.add(new_student)
        db.session.commit()

        flash('Account created successfully! Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('signup.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('login'))


# ==================== PROFILE ROUTE ====================

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    if request.method == 'POST':
        # Update basic info
        student.bio = request.form.get('bio', '').strip()
        student.phone = request.form.get('phone', '').strip()

        # Update profile picture (base64)
        profile_pic = request.form.get('profile_picture', '').strip()
        if profile_pic and profile_pic.startswith('data:image'):
            student.profile_picture = profile_pic

        # Update courses
        courses_input = request.form.get('courses', '')
        if courses_input:
            student.courses = ','.join([c.strip() for c in courses_input.split(',') if c.strip()])

        # Update skills
        skills_input = request.form.get('skills', '')
        if skills_input:
            student.skills = ','.join([s.strip() for s in skills_input.split(',') if s.strip()])

        try:
            db.session.commit()
            # Update connections based on courses
            update_course_connections(user_roll)
            flash('Profile updated successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating profile: {str(e)}', 'error')

        return redirect(url_for('profile'))

    # Get connection count
    connection_count = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).count()

    # Get badges
    badges = calculate_badges(user_roll)

    return render_template('profile.html', student=student.to_dict(), connection_count=connection_count, badges=badges)
# ==================== AI RESOURCE RECOMMENDATIONS ====================

def get_recommended_resources(user_roll, limit=6):
    """Get AI-powered resource recommendations based on user's courses"""
    student = StudentDB.query.get(user_roll)
    user_courses = set(student.courses.split(',')) if student.courses else set()
    user_courses = {c.strip().lower() for c in user_courses if c.strip()}

    if not user_courses:
        # If no courses, return most popular resources
        return ResourceDB.query.order_by(ResourceDB.views.desc()).limit(limit).all()

    # Score resources based on relevance
    all_resources = ResourceDB.query.filter(ResourceDB.uploader_roll != user_roll).all()
    scored_resources = []

    for resource in all_resources:
        score = 0
        resource_course = resource.course.lower().strip()

        # Check if resource course matches any user course
        for user_course in user_courses:
            if user_course in resource_course or resource_course in user_course:
                score += 100  # High relevance
                break

        # Boost score based on popularity (views and likes)
        score += resource.views * 0.5
        score += len(resource.likes.split(',')) * 2 if resource.likes else 0

        # Check resource tags match
        resource_tags = set(resource.tags.split(',')) if resource.tags else set()
        resource_tags = {t.strip().lower() for t in resource_tags if t.strip()}

        # Match with user skills
        user_skills = set(student.skills.split(',')) if student.skills else set()
        user_skills = {s.strip().lower() for s in user_skills if s.strip()}

        matching_tags = resource_tags & user_skills
        score += len(matching_tags) * 5

        if score > 0:
            scored_resources.append((score, resource))

    # Sort by score and return top results
    scored_resources.sort(key=lambda x: x[0], reverse=True)
    return [r[1] for r in scored_resources[:limit]]


# ==================== ANALYTICS ROUTE ====================
# ==================== ANALYTICS ROUTE ====================
@app.route('/analytics')
def analytics():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    # Track analytics page view
    track_activity(user_roll, 'analytics_view')

    # ========== CONNECTION TIMELINE (Last 30 days) ==========
    thirty_days_ago = datetime.now() - timedelta(days=30)

    # Get friendships instead of course connections
    friendships = FriendshipDB.query.filter_by(user_roll=user_roll).order_by(FriendshipDB.created_at).all()

    connection_timeline = {}
    cumulative_count = 0

    # Generate all dates in range
    current_date = thirty_days_ago.date()
    end_date = datetime.now().date()

    # Build timeline
    friendship_dates = [f.created_at.date() for f in friendships if f.created_at >= thirty_days_ago]
    friendship_dates.sort()

    date_index = 0
    while current_date <= end_date:
        while date_index < len(friendship_dates) and friendship_dates[date_index] <= current_date:
            cumulative_count += 1
            date_index += 1

        connection_timeline[current_date.isoformat()] = cumulative_count
        current_date += timedelta(days=1)

    # ========== RESOURCES DATA ==========
    user_resources = ResourceDB.query.filter_by(uploader_roll=user_roll).all()
    resources_by_course = {}
    total_views = 0
    total_likes = 0

    for res in user_resources:
        resources_by_course[res.course] = resources_by_course.get(res.course, 0) + 1
        total_views += res.views
        likes_list = [l for l in (res.likes or '').split(',') if l.strip()]
        total_likes += len(likes_list)

    # ========== SESSIONS DATA ==========
    user_sessions = StudySessionDB.query.filter(StudySessionDB.participants.contains(user_roll)).all()

    sessions_by_course = {}
    upcoming_sessions = 0
    today_str = datetime.now().strftime('%Y-%m-%d')

    for sess in user_sessions:
        sessions_by_course[sess.course] = sessions_by_course.get(sess.course, 0) + 1
        if sess.date >= today_str:
            upcoming_sessions += 1

    # ========== TOP CONNECTIONS ==========
    # FIXED: Define user_courses before using it
    user_courses = set([c.strip() for c in (student.courses or '').split(',') if c.strip()])

    friendships = FriendshipDB.query.filter_by(user_roll=user_roll).all()
    top_connections = []

    for friendship in friendships:
        friend = StudentDB.query.get(friendship.friend_roll)
        if friend:
            # Calculate shared courses
            friend_courses = set([c.strip() for c in (friend.courses or '').split(',') if c.strip()])
            shared_courses = user_courses & friend_courses

            top_connections.append({
                'name': friend.name,
                'roll': friend.roll_number,
                'shared_courses': len(shared_courses),
                'department': friend.department
            })

    top_connections.sort(key=lambda x: x['shared_courses'], reverse=True)
    top_connections = top_connections[:5]

    print(f"DEBUG Top Connections: {top_connections}")

    # ========== COURSE ENGAGEMENT ==========
    # ========== COURSE ENGAGEMENT ==========
    # Get user's courses as a list FIRST
    user_courses_list = [c.strip() for c in (student.courses or '').split(',') if c.strip()]

    # DEBUG: Check what data we have
    all_resources = ResourceDB.query.filter_by(uploader_roll=user_roll).all()
    print(f"DEBUG All User Resources:")
    for r in all_resources:
        print(f"  - Resource: '{r.title}', Course: '{r.course}'")

    all_user_sessions = StudySessionDB.query.filter(
        StudySessionDB.participants.contains(user_roll)
    ).all()
    print(f"DEBUG All User Sessions:")
    for s in all_user_sessions:
        print(f"  - Session: '{s.title}', Course: '{s.course}'")

    print(f"DEBUG User Profile Courses: '{student.courses}'")
    print(f"DEBUG User Courses List: {user_courses_list}")

    # Now calculate course engagement
    course_engagement = {}

    for course in user_courses_list:
        score = 0

        # Resources for this course
        resources_count = ResourceDB.query.filter_by(uploader_roll=user_roll, course=course).count()
        print(f"DEBUG Course '{course}' - Resources Found: {resources_count}")
        score += resources_count * 10

        # Sessions for this course
        sessions_count = StudySessionDB.query.filter(
            StudySessionDB.course == course,
            StudySessionDB.participants.contains(user_roll)
        ).count()
        print(f"DEBUG Course '{course}' - Sessions Found: {sessions_count}")
        score += sessions_count * 5

        # Add even if score is 0 (user enrolled in course)
        course_engagement[course] = max(score, 1)

    print(f"DEBUG Final Course Engagement: {course_engagement}")
    # ========== OVERALL STATS ==========
    # FIXED: Define connection_records before using it
    connection_records = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).all()

    total_connections = len(connection_records)
    total_sessions = len(user_sessions)
    total_resources_shared = len(user_resources)
    total_friends = FriendshipDB.query.filter_by(user_roll=user_roll).count()

    # ========== ADVANCED ANALYTICS ==========
    network_strength = calculate_network_strength(user_roll)
    learning_velocity = calculate_learning_velocity(user_roll)
    collaboration_index = calculate_collaboration_index(user_roll)
    peak_time = get_peak_activity_time(user_roll)
    attendance_rate = calculate_session_attendance_rate(user_roll)
    avg_response_time = calculate_avg_response_time(user_roll)
    engagement_percentage = get_engagement_percentage(user_roll)

    # ========== ACTIVITY DATA ==========
    heatmap_data = get_activity_heatmap(user_roll, days=90)
    hourly_activity = get_hourly_activity(user_roll, days=30)

    # ========== BUILD ANALYTICS DATA DICT ==========
    analytics_data = {
        'connection_timeline': connection_timeline,
        'resources_by_course': resources_by_course,
        'sessions_by_course': sessions_by_course,
        'top_connections': top_connections,
        'total_resources': total_resources_shared,
        'total_connections': total_connections,
        'total_friends': total_friends,
        'total_sessions': total_sessions,
        'upcoming_sessions': upcoming_sessions,
        'total_views': total_views,
        'total_likes': total_likes,
        'course_engagement': course_engagement,
        'network_strength': network_strength,
        'learning_velocity': learning_velocity,
        'collaboration_index': collaboration_index,
        'peak_time': peak_time,
        'attendance_rate': attendance_rate,
        'avg_response_time': avg_response_time,
        'engagement_percentage': engagement_percentage,
        'heatmap_data': heatmap_data,
        'hourly_activity': hourly_activity,
    }

    # Calculate badges
    badges = calculate_badges(user_roll)

    # DEBUG: Print to console to verify data
    print("=" * 50)
    print("ANALYTICS DATA FOR:", user_roll)
    print("Total Connections:", total_connections)
    print("Total Friends:", total_friends)
    print("Total Resources:", total_resources_shared)
    print("Total Sessions:", total_sessions)
    print("Hourly Activity Length:", len(hourly_activity))
    print("Heatmap Data Length:", len(heatmap_data))
    print("Course Engagement:", course_engagement)
    print("=" * 50)

    return render_template('analytics.html',
                           student=student.to_dict(),
                           analytics=analytics_data,
                           badges=badges)
# ==================== DASHBOARD ROUTE ====================

# REPLACE YOUR DASHBOARD ROUTE WITH THIS

@app.route('/dashboard')
def dashboard():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    # Get connection count
    user_connections = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).count()

    # Get groups count
    #user_groups = StudyGroupDB.query.filter(StudyGroupDB.members.contains(user_roll)).count()

    # Get upcoming sessions count
    upcoming_sessions = StudySessionDB.query.filter(
        StudySessionDB.participants.contains(user_roll),
        StudySessionDB.date >= datetime.now().strftime('%Y-%m-%d')
    ).count()

    stats = {
        'user_connections': user_connections,
        #'user_groups': user_groups,
        'upcoming_sessions': upcoming_sessions
    }

    # Get AI-powered recommendations (top 6)
    recommended_resources = get_recommended_resources(user_roll, limit=6)

    return render_template('dashboard.html',
                          student=student.to_dict(),
                          stats=stats,
                          recommended_resources=recommended_resources)

# ==================== API FOR GRAPH DATA ====================

@app.route('/api/graph-data')
def get_graph_data():
    if 'user_roll' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    students = StudentDB.query.all()
    connections = ConnectionDB.query.all()

    nodes = []
    for s in students:
        nodes.append({
            'id': s.roll_number,
            'label': s.name,
            'group': s.department,
            'courses': s.courses.split(',') if s.courses else [],
            'skills': s.skills.split(',') if s.skills else []
        })

    edges = []
    for c in connections:
        edges.append({
            'from': c.student1_roll,
            'to': c.student2_roll,
            'title': f"Shared Courses: {c.shared_courses}"
        })

    return jsonify({'nodes': nodes, 'edges': edges})


# ==================== COURSES ROUTE ====================

@app.route('/courses')
def courses():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)
    user_courses = student.courses.split(',') if student.courses else []

    all_students = get_all_students_dict()
    connections_by_course = {}

    for course in user_courses:
        if course:
            course_students = search_students_by_course(all_students, course)
            course_students = [s for s in course_students if s['roll_number'] != user_roll]
            connections_by_course[course] = course_students

    return render_template('courses.html', student=student.to_dict(), connections_by_course=connections_by_course)


# ==================== STUDY GROUPS ROUTES ====================
'''
@app.route('/groups')
def groups():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    all_groups = StudyGroupDB.query.all()
    my_groups = [g for g in all_groups if user_roll in (g.members or '')]
    available_groups = [g for g in all_groups if user_roll not in (g.members or '') and g.is_active]

    return render_template('groups.html', student=student.to_dict(), my_groups=my_groups,
                           available_groups=available_groups)


@app.route('/groups/create', methods=['POST'])
def create_group():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']

    new_group = StudyGroupDB(
        group_id=str(uuid.uuid4())[:8],
        name=request.form.get('name'),
        course=request.form.get('course'),
        creator_roll=user_roll,
        description=request.form.get('description', ''),
        max_members=int(request.form.get('max_members', 10)),
        members=user_roll
    )
    db.session.add(new_group)
    db.session.commit()

    flash('Group created successfully!', 'success')
    return redirect(url_for('groups'))


@app.route('/groups/<group_id>/join', methods=['POST'])
def join_group(group_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    group = StudyGroupDB.query.get(group_id)

    if group:
        members = group.members.split(',') if group.members else []
        if user_roll not in members and len(members) < group.max_members:
            members.append(user_roll)
            group.members = ','.join(members)
            db.session.commit()
            flash('Joined group successfully!', 'success')
        else:
            flash('Cannot join group', 'error')

    return redirect(url_for('groups'))


@app.route('/groups/<group_id>/leave', methods=['POST'])
def leave_group(group_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    group = StudyGroupDB.query.get(group_id)

    if group and group.creator_roll != user_roll:
        members = group.members.split(',') if group.members else []
        if user_roll in members:
            members.remove(user_roll)
            group.members = ','.join(members)
            db.session.commit()
            flash('Left group successfully', 'success')

    return redirect(url_for('groups'))

'''
# ==================== SKILLS ROUTE ====================

@app.route('/skills')
def skills():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    # Get existing friends
    existing_friends = FriendshipDB.query.filter_by(user_roll=user_roll).all()
    friend_rolls = [f.friend_roll for f in existing_friends]

    all_students = get_all_students_dict()
    ranked_matches = rank_matches(all_students, student.to_dict())

    # Filter out existing friends and self
    filtered_matches = [
        match for match in ranked_matches
        if match['roll_number'] != user_roll and match['roll_number'] not in friend_rolls
    ]

    top_matches = filtered_matches[:10]

    return render_template('skills.html', student=student.to_dict(), top_matches=top_matches)


# ==================== SESSIONS ROUTES ====================
@app.route('/sessions')
def sessions():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    # Get filter parameters
    filter_course = request.args.get('course', '')
    filter_status = request.args.get('status', 'all')
    search_query = request.args.get('search', '')

    # Base query
    all_sessions_db = StudySessionDB.query.all()

    today = datetime.now().strftime('%Y-%m-%d')
    now_time = datetime.now().strftime('%H:%M')

    # Categorize sessions
    my_sessions = []
    upcoming_sessions = []
    past_sessions = []

    for s in all_sessions_db:
        session_dict = s.to_dict()

        # Get organizer info
        organizer = StudentDB.query.get(s.organizer_roll)
        session_dict['organizer_name'] = organizer.name if organizer else 'Unknown'

        # Get participants count
        participants = [p for p in (s.participants or '').split(',') if p.strip()]
        session_dict['participant_count'] = len(participants)
        session_dict['is_participant'] = user_roll in participants
        session_dict['spots_left'] = s.max_participants - len(participants)

        # Determine session status
        if s.date > today:
            session_dict['status'] = 'upcoming'
            session_dict['status_color'] = 'success'
        elif s.date == today:
            if s.time > now_time:
                session_dict['status'] = 'today'
                session_dict['status_color'] = 'warning'
            else:
                session_dict['status'] = 'past'
                session_dict['status_color'] = 'secondary'
        else:
            session_dict['status'] = 'past'
            session_dict['status_color'] = 'secondary'

        # Apply filters
        if search_query and search_query.lower() not in session_dict['title'].lower() and search_query.lower() not in session_dict['course'].lower():
            continue

        if filter_course and session_dict['course'] != filter_course:
            continue

        # Categorize
        if session_dict['is_participant']:
            my_sessions.append(session_dict)

        if session_dict['status'] in ['upcoming', 'today']:
            upcoming_sessions.append(session_dict)
        else:
            past_sessions.append(session_dict)

    # Get unique courses for filter
    all_courses = set()
    for s in all_sessions_db:
        all_courses.add(s.course)

    # FIXED: Pass datetime to template
    return render_template('sessions.html',
                          student=student.to_dict(),
                          my_sessions=my_sessions,
                          upcoming_sessions=upcoming_sessions,
                          past_sessions=past_sessions,
                          all_courses=sorted(all_courses),
                          filter_course=filter_course,
                          filter_status=filter_status,
                          search_query=search_query,
                          datetime=datetime)  # <-- ADD THIS LINE


@app.route('/sessions/<session_id>/leave', methods=['POST'])
def leave_session(session_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    study_session = StudySessionDB.query.get(session_id)

    if study_session and study_session.organizer_roll != user_roll:
        participants = (study_session.participants or '').split(',')
        participants = [p for p in participants if p.strip()]
        if user_roll in participants:
            participants.remove(user_roll)
            study_session.participants = ','.join(participants)
            db.session.commit()
            flash('Left session successfully!', 'success')
    else:
        flash('Cannot leave session (you are the organizer)', 'error')

    return redirect(url_for('sessions'))


@app.route('/sessions/<session_id>/cancel', methods=['POST'])
def cancel_session(session_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    study_session = StudySessionDB.query.get(session_id)

    if study_session and study_session.organizer_roll == user_roll:
        db.session.delete(study_session)
        db.session.commit()
        flash('Session cancelled successfully!', 'success')
    else:
        flash('You can only cancel your own sessions', 'error')

    return redirect(url_for('sessions'))


@app.route('/sessions/<session_id>/details')
def session_details(session_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)
    study_session = StudySessionDB.query.get(session_id)

    if not study_session:
        flash('Session not found', 'error')
        return redirect(url_for('sessions'))

    session_dict = study_session.to_dict()

    # Get organizer info
    organizer = StudentDB.query.get(study_session.organizer_roll)
    session_dict['organizer'] = organizer.to_dict() if organizer else None

    # Get all participants info
    participant_rolls = [p for p in (study_session.participants or '').split(',') if p.strip()]
    participants = []
    for roll in participant_rolls:
        p = StudentDB.query.get(roll)
        if p:
            participants.append(p.to_dict())

    session_dict['participants_list'] = participants
    session_dict['is_participant'] = user_roll in participant_rolls
    session_dict['is_organizer'] = user_roll == study_session.organizer_roll
    session_dict['spots_left'] = study_session.max_participants - len(participants)

    # Check if session is past
    today = datetime.now().strftime('%Y-%m-%d')
    session_dict['is_past'] = study_session.date < today

    # FIXED: Pass datetime to template
    return render_template('session_details.html',
                          student=student.to_dict(),
                          session=session_dict,
                          datetime=datetime)  # <-- KEEP THIS

@app.route('/sessions/create', methods=['POST'])

def create_session():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']

    new_session = StudySessionDB(
        session_id=str(uuid.uuid4())[:8],
        title=request.form.get('title'),
        course=request.form.get('course'),
        organizer_roll=user_roll,
        date=request.form.get('date'),
        time=request.form.get('time'),
        location=request.form.get('location'),
        description=request.form.get('description', ''),
        max_participants=int(request.form.get('max_participants', 10)),
        participants=user_roll
    )
    db.session.add(new_session)
    db.session.commit()

    flash('Session created successfully!', 'success')
    return redirect(url_for('sessions'))


@app.route('/sessions/<session_id>/join', methods=['POST'])
def join_session(session_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    study_session = StudySessionDB.query.get(session_id)

    if study_session:
        participants = (study_session.participants or '').split(',')
        participants = [p for p in participants if p.strip()]
        if user_roll not in participants and len(participants) < study_session.max_participants:
            participants.append(user_roll)
            study_session.participants = ','.join(participants)
            track_activity(user_roll, 'session_join', {'session_id': session_id})
            db.session.commit()
            flash('Joined session successfully!', 'success')
        else:
            flash('Cannot join session - already joined or session is full', 'error')

    return redirect(url_for('sessions'))

# ==================== RESOURCES ROUTES ====================

@app.route('/resources')
def resources():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    all_resources = ResourceDB.query.order_by(ResourceDB.uploaded_at.desc()).all()
    resources_data = [r.to_dict() for r in all_resources]

    return render_template('resources.html', student=student.to_dict(), resources=resources_data)


@app.route('/resources/create', methods=['POST'])
def create_resource():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    tags_input = request.form.get('tags', '')

    new_resource = ResourceDB(
        resource_id=str(uuid.uuid4())[:8],
        title=request.form.get('title'),
        course=request.form.get('course'),
        uploader_roll=user_roll,
        resource_type=request.form.get('resource_type'),
        url=request.form.get('url'),
        description=request.form.get('description', ''),
        tags=','.join([t.strip() for t in tags_input.split(',') if t.strip()])
    )
    db.session.add(new_resource)
    db.session.commit()

    flash('Resource shared successfully!', 'success')
    return redirect(url_for('resources'))


@app.route('/resources/<resource_id>/like', methods=['POST'])
def like_resource(resource_id):
    if 'user_roll' not in session:
        return jsonify({'error': 'Not authenticated', 'success': False}), 401

    try:
        user_roll = session['user_roll']
        resource = ResourceDB.query.get(resource_id)

        if not resource:
            return jsonify({'error': 'Resource not found', 'success': False}), 404

        # Handle likes as string
        likes = resource.likes.split(',') if resource.likes else []
        likes = [l.strip() for l in likes if l.strip()]

        if user_roll in likes:
            likes.remove(user_roll)
            liked = False
        else:
            likes.append(user_roll)
            liked = True

        resource.likes = ','.join(likes) if likes else ''
        db.session.commit()

        return jsonify({'success': True, 'liked': liked, 'like_count': len(likes)})

    except Exception as e:
        db.session.rollback()
        print(f"Error in like_resource: {str(e)}")  # Debug logging
        return jsonify({'error': str(e), 'success': False}), 500

@app.route('/resources/<resource_id>/view', methods=['POST'])
def view_resource(resource_id):
    if 'user_roll' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    resource = ResourceDB.query.get(resource_id)

    if resource:
        resource.views += 1
        track_activity('user_roll', 'resource_view', {'resource_id': resource_id})
        db.session.commit()
        return jsonify({'success': True, 'views': resource.views})


    return jsonify({'error': 'Resource not found'}), 404


@app.route('/resources/<resource_id>/delete', methods=['POST'])
def delete_resource(resource_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    resource = ResourceDB.query.get(resource_id)

    if resource and resource.uploader_roll == user_roll:
        db.session.delete(resource)
        db.session.commit()
        flash('Resource deleted successfully!', 'success')
    else:
        flash('Cannot delete resource', 'error')

    return redirect(url_for('resources'))


# ==================== FRIENDS ROUTES ====================

@app.route('/friends')
def friends():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    # Get search query if exists
    search_query = request.args.get('search', '').strip()
    search_type = request.args.get('search_type', 'all')

    # Get all friends
    friendships = FriendshipDB.query.filter_by(user_roll=user_roll).all()
    my_friends = []
    for f in friendships:
        friend = StudentDB.query.get(f.friend_roll)
        if friend:
            friend_dict = friend.to_dict()
            friend_dict['friendship_date'] = f.created_at.strftime('%Y-%m-%d')

            # IMPORTANT: Ensure courses is a list for template
            if isinstance(friend_dict.get('courses'), str):
                friend_dict['courses'] = [c.strip() for c in friend_dict['courses'].split(',') if c.strip()]
            elif not friend_dict.get('courses'):
                friend_dict['courses'] = []

            # Same for skills
            if isinstance(friend_dict.get('skills'), str):
                friend_dict['skills'] = [s.strip() for s in friend_dict['skills'].split(',') if s.strip()]
            elif not friend_dict.get('skills'):
                friend_dict['skills'] = []

            my_friends.append(friend_dict)

    # Get friend suggestions
    friend_rolls = [f.friend_roll for f in friendships]
    all_students = StudentDB.query.filter(
        StudentDB.roll_number != user_roll
    ).all()

    # Filter out existing friends
    all_students = [s for s in all_students if s.roll_number not in friend_rolls]

    # Calculate match scores
    user_courses = set((student.courses or '').split(','))
    user_courses = {c.strip().lower() for c in user_courses if c.strip()}
    user_skills = set((student.skills or '').split(','))
    user_skills = {s.strip().lower() for s in user_skills if s.strip()}

    suggestions = []
    for other in all_students:
        other_courses = set((other.courses or '').split(','))
        other_courses = {c.strip().lower() for c in other_courses if c.strip()}
        other_skills = set((other.skills or '').split(','))
        other_skills = {s.strip().lower() for s in other_skills if s.strip()}

        shared_courses = user_courses & other_courses
        shared_skills = user_skills & other_skills

        match_score = len(shared_courses) * 10 + len(shared_skills) * 5

        if other.department == student.department:
            match_score += 3

        if match_score > 0:
            other_dict = other.to_dict()
            other_dict['match_score'] = match_score
            other_dict['shared_courses'] = list(shared_courses)
            other_dict['shared_skills'] = list(shared_skills)

            # IMPORTANT: Convert courses and skills to lists for template
            if isinstance(other_dict.get('courses'), str):
                other_dict['courses'] = [c.strip() for c in other_dict['courses'].split(',') if c.strip()]
            elif not other_dict.get('courses'):
                other_dict['courses'] = []

            if isinstance(other_dict.get('skills'), str):
                other_dict['skills'] = [s.strip() for s in other_dict['skills'].split(',') if s.strip()]
            elif not other_dict.get('skills'):
                other_dict['skills'] = []

            suggestions.append(other_dict)

    suggestions.sort(key=lambda x: x['match_score'], reverse=True)

    # Apply search filter
    if search_query:
        search_lower = search_query.lower()

        if search_type == 'friends' or search_type == 'all':
            my_friends = [f for f in my_friends
                          if search_lower in f['name'].lower()
                          or search_lower in f['roll_number'].lower()
                          or search_lower in (f.get('email') or '').lower()
                          or search_lower in f['department'].lower()]

        if search_type == 'suggestions' or search_type == 'all':
            suggestions = [s for s in suggestions
                           if search_lower in s['name'].lower()
                           or search_lower in s['roll_number'].lower()
                           or search_lower in (s.get('email') or '').lower()
                           or search_lower in s['department'].lower()]

    return render_template('friends.html',
                           student=student.to_dict(),
                           my_friends=my_friends,
                           suggestions=suggestions[:20],
                           search_query=search_query,
                           search_type=search_type)
@app.route('/friends/add/<friend_roll>', methods=['POST'])
def add_friend(friend_roll):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']

    if user_roll == friend_roll:
        flash('Cannot add yourself!', 'error')
        return redirect(url_for('friends'))

    existing = FriendshipDB.query.filter_by(user_roll=user_roll, friend_roll=friend_roll).first()

    if not existing:
        friendship = FriendshipDB(user_roll=user_roll, friend_roll=friend_roll)
        db.session.add(friendship)
        db.session.commit()
        flash('Friend added successfully!', 'success')
    else:
        flash('Already friends!', 'info')

    return redirect(url_for('friends'))


@app.route('/friends/remove/<friend_roll>', methods=['POST'])
def remove_friend(friend_roll):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']

    friendship = FriendshipDB.query.filter_by(user_roll=user_roll, friend_roll=friend_roll).first()

    if friendship:
        db.session.delete(friendship)
        db.session.commit()
        flash('Friend removed successfully!', 'success')

    return redirect(url_for('friends'))


@app.route('/friends/<friend_roll>/message', methods=['POST'])
def send_message(friend_roll):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    message_text = request.form.get('message')

    if message_text:
        message = MessageDB(
            from_roll=user_roll,
            to_roll=friend_roll,
            message=message_text
        )
        db.session.add(message)
        db.session.commit()
        track_activity(user_roll, 'message_sent', {'to': friend_roll})
        flash('Message sent!', 'success')


    return redirect(url_for('friends'))


@app.route('/friends/messages')
def view_messages():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    messages = MessageDB.query.filter(
        (MessageDB.from_roll == user_roll) | (MessageDB.to_roll == user_roll)
    ).order_by(MessageDB.timestamp.desc()).all()

    messages_data = []
    for m in messages:
        msg = m.to_dict()
        msg['from_student'] = StudentDB.query.get(m.from_roll).to_dict() if StudentDB.query.get(m.from_roll) else None
        msg['to_student'] = StudentDB.query.get(m.to_roll).to_dict() if StudentDB.query.get(m.to_roll) else None
        messages_data.append(msg)

    return render_template('messages.html', student=student.to_dict(), messages=messages_data)

# ==================== SEARCH ROUTE ====================

@app.route('/search')
def search():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    query = request.args.get('q', '')
    filter_type = request.args.get('type', 'name')

    student = StudentDB.query.get(session['user_roll'])
    all_students = get_all_students_dict()
    results = []

    if query:
        if filter_type == 'name':
            results = search_students_by_name(all_students, query)
        elif filter_type == 'course':
            results = search_students_by_course(all_students, query)

    return render_template('search.html', student=student.to_dict(), query=query, filter_type=filter_type,
                           results=results)


# ==================== RUN APP ====================

if __name__ == '__main__':
    app.run(debug=True, port=5000)