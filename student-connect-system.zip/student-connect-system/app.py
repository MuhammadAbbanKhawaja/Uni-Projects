from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
import os
import uuid
from datetime import datetime

# Import database
from models.database import db, StudentDB, FriendshipDB, MessageDB, StudyGroupDB, StudySessionDB, ResourceDB, \
    ConnectionDB

# Import data structures (still used for in-memory operations)
from data_structures.hash_map import HashMap
from data_structures.graph import Graph

# Import algorithms
from algorithms.search import search_students_by_name, search_students_by_course
from algorithms.sort import rank_matches, sort_sessions_by_date, sort_resources_by_date
from algorithms.graph_algorithms import suggest_connections

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production'

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///student_connect.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db.init_app(app)

# Create tables
with app.app_context():
    db.create_all()
    print("✅ Database tables created!")


# ==================== HELPER FUNCTIONS ====================

def get_all_students_dict():
    """Get all students as list of dictionaries"""
    students = StudentDB.query.all()
    return [s.to_dict() for s in students]


def get_student_hashmap():
    """Build HashMap from database"""
    hashmap = HashMap()
    students = StudentDB.query.all()
    for s in students:
        hashmap.insert(s.roll_number, s.to_dict())
    return hashmap


def get_connection_graph():
    """Build Graph from database"""
    graph = Graph()
    students = StudentDB.query.all()
    for s in students:
        graph.add_vertex(s.roll_number)

    connections = ConnectionDB.query.all()
    for c in connections:
        graph.add_edge(c.student1_roll, c.student2_roll,
                       weight={'shared_courses': c.shared_courses.split(',') if c.shared_courses else []})
    return graph


# ==================== ACHIEVEMENT BADGES ====================

def calculate_badges(user_roll):
    """Calculate achievement badges for a user"""
    student = StudentDB.query.get(user_roll)
    badges = []

    # Connection Badges
    connection_count = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).count()

    if connection_count >= 1:
        badges.append(
            {'name': 'First Connection', 'icon': '🤝', 'color': 'primary', 'desc': 'Made your first connection'})
    if connection_count >= 5:
        badges.append({'name': 'Networker', 'icon': '🌐', 'color': 'info', 'desc': 'Connected with 5+ students'})
    if connection_count >= 10:
        badges.append(
            {'name': 'Social Butterfly', 'icon': '🦋', 'color': 'success', 'desc': 'Connected with 10+ students'})

    # Friend Badges
    friend_count = FriendshipDB.query.filter_by(user_roll=user_roll).count()

    if friend_count >= 1:
        badges.append({'name': 'Friendly', 'icon': '👋', 'color': 'warning', 'desc': 'Added your first friend'})
    if friend_count >= 5:
        badges.append({'name': 'Popular', 'icon': '⭐', 'color': 'warning', 'desc': 'Made 5+ friends'})

    # Resource Badges
    resource_count = ResourceDB.query.filter_by(uploader_roll=user_roll).count()

    if resource_count >= 1:
        badges.append({'name': 'Contributor', 'icon': '📚', 'color': 'info', 'desc': 'Shared your first resource'})
    if resource_count >= 5:
        badges.append({'name': 'Resource Master', 'icon': '🎓', 'color': 'success', 'desc': 'Shared 5+ resources'})
    if resource_count >= 10:
        badges.append({'name': 'Knowledge Guru', 'icon': '🧠', 'color': 'danger', 'desc': 'Shared 10+ resources'})

    # Group Badges
    groups_created = StudyGroupDB.query.filter_by(creator_roll=user_roll).count()
    groups_joined = StudyGroupDB.query.filter(StudyGroupDB.members.contains(user_roll)).count()

    if groups_created >= 1:
        badges.append({'name': 'Group Leader', 'icon': '👥', 'color': 'primary', 'desc': 'Created a study group'})
    if groups_joined >= 3:
        badges.append({'name': 'Team Player', 'icon': '🤝', 'color': 'success', 'desc': 'Joined 3+ study groups'})

    # Session Badges
    sessions_created = StudySessionDB.query.filter_by(organizer_roll=user_roll).count()

    if sessions_created >= 1:
        badges.append({'name': 'Organizer', 'icon': '📅', 'color': 'info', 'desc': 'Organized a study session'})
    if sessions_created >= 5:
        badges.append({'name': 'Study Master', 'icon': '📖', 'color': 'warning', 'desc': 'Organized 5+ sessions'})

    # Message Badges
    messages_sent = MessageDB.query.filter_by(from_roll=user_roll).count()

    if messages_sent >= 1:
        badges.append({'name': 'Communicator', 'icon': '💬', 'color': 'primary', 'desc': 'Sent your first message'})
    if messages_sent >= 10:
        badges.append({'name': 'Chatterbox', 'icon': '💭', 'color': 'success', 'desc': 'Sent 10+ messages'})

    # Profile Completion Badge
    if student and student.bio and student.phone and student.courses and student.skills:
        badges.append({'name': 'Profile Pro', 'icon': '✨', 'color': 'danger', 'desc': 'Completed your profile'})

    return badges


# ==================== AUTHENTICATION ROUTES ====================

@app.route('/')
def index():
    if 'user_roll' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        roll_number = request.form.get('roll_number')
        password = request.form.get('password')

        student = StudentDB.query.get(roll_number)

        if student and student.password == password:
            session['user_roll'] = roll_number
            session['user_name'] = student.name
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid roll number or password', 'error')

    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        roll_number = request.form.get('roll_number')
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        department = request.form.get('department')
        semester = int(request.form.get('semester', 1))

        if StudentDB.query.get(roll_number):
            flash('Roll number already registered!', 'error')
            return render_template('signup.html')

        new_student = StudentDB(
            roll_number=roll_number,
            name=name,
            email=email,
            password=password,
            department=department,
            semester=semester
        )
        db.session.add(new_student)
        db.session.commit()

        flash('Account created successfully! Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('signup.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('login'))


# ==================== PROFILE ROUTE ====================

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    if request.method == 'POST':
        student.bio = request.form.get('bio', '')
        student.phone = request.form.get('phone', '')

        # Update profile picture
        profile_pic = request.form.get('profile_picture', '')
        if profile_pic:
            student.profile_picture = profile_pic

        # Update courses
        courses_input = request.form.get('courses', '')
        student.courses = ','.join([c.strip() for c in courses_input.split(',') if c.strip()])

        # Update skills - FIXED HERE
        skills_input = request.form.get('skills', '')
        student.skills = ','.join([s.strip() for s in skills_input.split(',') if s.strip()])

        db.session.commit()

        # Update connections based on courses
        update_course_connections(user_roll)

        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile'))

    # Get connection count
    connection_count = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).count()

    # Get badges
    badges = calculate_badges(user_roll)

    return render_template('profile.html', student=student.to_dict(), connection_count=connection_count, badges=badges)


# ==================== AI RESOURCE RECOMMENDATIONS ====================

def get_recommended_resources(user_roll, limit=6):
    """Get AI-powered resource recommendations based on user's courses"""
    student = StudentDB.query.get(user_roll)
    user_courses = set(student.courses.split(',')) if student.courses else set()
    user_courses = {c.strip().lower() for c in user_courses if c.strip()}

    if not user_courses:
        # If no courses, return most popular resources
        return ResourceDB.query.order_by(ResourceDB.views.desc()).limit(limit).all()

    # Score resources based on relevance
    all_resources = ResourceDB.query.filter(ResourceDB.uploader_roll != user_roll).all()
    scored_resources = []

    for resource in all_resources:
        score = 0
        resource_course = resource.course.lower().strip()

        # Check if resource course matches any user course
        for user_course in user_courses:
            if user_course in resource_course or resource_course in user_course:
                score += 100  # High relevance
                break

        # Boost score based on popularity (views and likes)
        score += resource.views * 0.5
        score += len(resource.likes.split(',')) * 2 if resource.likes else 0

        # Check resource tags match
        resource_tags = set(resource.tags.split(',')) if resource.tags else set()
        resource_tags = {t.strip().lower() for t in resource_tags if t.strip()}

        # Match with user skills
        user_skills = set(student.skills.split(',')) if student.skills else set()
        user_skills = {s.strip().lower() for s in user_skills if s.strip()}

        matching_tags = resource_tags & user_skills
        score += len(matching_tags) * 5

        if score > 0:
            scored_resources.append((score, resource))

    # Sort by score and return top results
    scored_resources.sort(key=lambda x: x[0], reverse=True)
    return [r[1] for r in scored_resources[:limit]]


# ==================== ANALYTICS ROUTE ====================

@app.route('/analytics')
def analytics():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    # Connection growth over time
    connections = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).order_by(ConnectionDB.created_at).all()

    connection_dates = {}
    for conn in connections:
        date = conn.created_at.strftime('%Y-%m-%d')
        connection_dates[date] = connection_dates.get(date, 0) + 1

    # Resources by course
    user_resources = ResourceDB.query.filter_by(uploader_roll=user_roll).all()
    resources_by_course = {}
    for res in user_resources:
        resources_by_course[res.course] = resources_by_course.get(res.course, 0) + 1

    # Message activity
    messages_sent = MessageDB.query.filter_by(from_roll=user_roll).count()
    messages_received = MessageDB.query.filter_by(to_roll=user_roll).count()

    # Groups and sessions
    groups_count = StudyGroupDB.query.filter(StudyGroupDB.members.contains(user_roll)).count()
    sessions_count = StudySessionDB.query.filter(StudySessionDB.participants.contains(user_roll)).count()

    # Top connections (people with shared courses)
    user_courses = set(student.courses.split(',')) if student.courses else set()
    all_students = StudentDB.query.filter(StudentDB.roll_number != user_roll).all()

    top_connections = []
    for other in all_students[:10]:
        other_courses = set(other.courses.split(',')) if other.courses else set()
        shared = len(user_courses & other_courses)
        if shared > 0:
            top_connections.append({
                'name': other.name,
                'shared_courses': shared
            })

    top_connections.sort(key=lambda x: x['shared_courses'], reverse=True)
    top_connections = top_connections[:5]

    analytics_data = {
        'connection_dates': connection_dates,
        'resources_by_course': resources_by_course,
        'messages_sent': messages_sent,
        'messages_received': messages_received,
        'groups_count': groups_count,
        'sessions_count': sessions_count,
        'top_connections': top_connections,
        'total_resources': len(user_resources),
        'total_connections': len(connections)
    }

    return render_template('analytics.html', student=student.to_dict(), analytics=analytics_data)


def update_course_connections(user_roll):
    """Update graph connections based on shared courses"""
    user = StudentDB.query.get(user_roll)
    user_courses = set(user.courses.split(',')) if user.courses else set()

    # Remove old connections
    ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).delete()

    # Create new connections
    all_students = StudentDB.query.filter(StudentDB.roll_number != user_roll).all()

    for other in all_students:
        other_courses = set(other.courses.split(',')) if other.courses else set()
        shared = user_courses & other_courses

        if shared and '' not in shared:
            connection = ConnectionDB(
                student1_roll=user_roll,
                student2_roll=other.roll_number,
                shared_courses=','.join(shared)
            )
            db.session.add(connection)

    db.session.commit()


# ==================== DASHBOARD ROUTE ====================

@app.route('/dashboard')
def dashboard():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    total_students = StudentDB.query.count()
    user_connections = ConnectionDB.query.filter(
        (ConnectionDB.student1_roll == user_roll) | (ConnectionDB.student2_roll == user_roll)
    ).count()

    user_groups = StudyGroupDB.query.filter(StudyGroupDB.members.contains(user_roll)).count()

    upcoming_sessions = StudySessionDB.query.filter(
        StudySessionDB.participants.contains(user_roll),
        StudySessionDB.date >= datetime.now().strftime('%Y-%m-%d')
    ).count()

    stats = {
        'total_students': total_students,
        'user_connections': user_connections,
        'user_groups': user_groups,
        'upcoming_sessions': upcoming_sessions
    }

    # Get AI recommendations
    recommended_resources = get_recommended_resources(user_roll)

    return render_template('dashboard.html', student=student.to_dict(), stats=stats,
                           recommended_resources=recommended_resources)

# ==================== API FOR GRAPH DATA ====================

@app.route('/api/graph-data')
def get_graph_data():
    if 'user_roll' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    students = StudentDB.query.all()
    connections = ConnectionDB.query.all()

    nodes = []
    for s in students:
        nodes.append({
            'id': s.roll_number,
            'label': s.name,
            'group': s.department,
            'courses': s.courses.split(',') if s.courses else [],
            'skills': s.skills.split(',') if s.skills else []
        })

    edges = []
    for c in connections:
        edges.append({
            'from': c.student1_roll,
            'to': c.student2_roll,
            'title': f"Shared Courses: {c.shared_courses}"
        })

    return jsonify({'nodes': nodes, 'edges': edges})


# ==================== COURSES ROUTE ====================

@app.route('/courses')
def courses():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)
    user_courses = student.courses.split(',') if student.courses else []

    all_students = get_all_students_dict()
    connections_by_course = {}

    for course in user_courses:
        if course:
            course_students = search_students_by_course(all_students, course)
            course_students = [s for s in course_students if s['roll_number'] != user_roll]
            connections_by_course[course] = course_students

    return render_template('courses.html', student=student.to_dict(), connections_by_course=connections_by_course)


# ==================== STUDY GROUPS ROUTES ====================

@app.route('/groups')
def groups():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    all_groups = StudyGroupDB.query.all()
    my_groups = [g for g in all_groups if user_roll in (g.members or '')]
    available_groups = [g for g in all_groups if user_roll not in (g.members or '') and g.is_active]

    return render_template('groups.html', student=student.to_dict(), my_groups=my_groups,
                           available_groups=available_groups)


@app.route('/groups/create', methods=['POST'])
def create_group():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']

    new_group = StudyGroupDB(
        group_id=str(uuid.uuid4())[:8],
        name=request.form.get('name'),
        course=request.form.get('course'),
        creator_roll=user_roll,
        description=request.form.get('description', ''),
        max_members=int(request.form.get('max_members', 10)),
        members=user_roll
    )
    db.session.add(new_group)
    db.session.commit()

    flash('Group created successfully!', 'success')
    return redirect(url_for('groups'))


@app.route('/groups/<group_id>/join', methods=['POST'])
def join_group(group_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    group = StudyGroupDB.query.get(group_id)

    if group:
        members = group.members.split(',') if group.members else []
        if user_roll not in members and len(members) < group.max_members:
            members.append(user_roll)
            group.members = ','.join(members)
            db.session.commit()
            flash('Joined group successfully!', 'success')
        else:
            flash('Cannot join group', 'error')

    return redirect(url_for('groups'))


@app.route('/groups/<group_id>/leave', methods=['POST'])
def leave_group(group_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    group = StudyGroupDB.query.get(group_id)

    if group and group.creator_roll != user_roll:
        members = group.members.split(',') if group.members else []
        if user_roll in members:
            members.remove(user_roll)
            group.members = ','.join(members)
            db.session.commit()
            flash('Left group successfully', 'success')

    return redirect(url_for('groups'))


# ==================== SKILLS ROUTE ====================

@app.route('/skills')
def skills():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    all_students = get_all_students_dict()
    ranked_matches = rank_matches(all_students, student.to_dict())
    top_matches = ranked_matches[:10]

    return render_template('skills.html', student=student.to_dict(), top_matches=top_matches)


# ==================== SESSIONS ROUTES ====================

@app.route('/sessions')
def sessions():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    all_sessions = StudySessionDB.query.filter(
        StudySessionDB.date >= datetime.now().strftime('%Y-%m-%d')
    ).all()

    my_sessions = [s.to_dict() for s in all_sessions if user_roll in (s.participants or '')]
    available_sessions = [s.to_dict() for s in all_sessions if user_roll not in (s.participants or '')]

    return render_template('sessions.html', student=student.to_dict(), my_sessions=my_sessions,
                           available_sessions=available_sessions)


@app.route('/sessions/create', methods=['POST'])
def create_session():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']

    new_session = StudySessionDB(
        session_id=str(uuid.uuid4())[:8],
        title=request.form.get('title'),
        course=request.form.get('course'),
        organizer_roll=user_roll,
        date=request.form.get('date'),
        time=request.form.get('time'),
        location=request.form.get('location'),
        description=request.form.get('description', ''),
        max_participants=int(request.form.get('max_participants', 10)),
        participants=user_roll
    )
    db.session.add(new_session)
    db.session.commit()

    flash('Session created successfully!', 'success')
    return redirect(url_for('sessions'))


@app.route('/sessions/<session_id>/join', methods=['POST'])
def join_session(session_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    study_session = StudySessionDB.query.get(session_id)

    if study_session:
        participants = study_session.participants.split(',') if study_session.participants else []
        if user_roll not in participants:
            participants.append(user_roll)
            study_session.participants = ','.join(participants)
            db.session.commit()
            flash('Joined session successfully!', 'success')

    return redirect(url_for('sessions'))


# ==================== RESOURCES ROUTES ====================

@app.route('/resources')
def resources():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    all_resources = ResourceDB.query.order_by(ResourceDB.uploaded_at.desc()).all()
    resources_data = [r.to_dict() for r in all_resources]

    return render_template('resources.html', student=student.to_dict(), resources=resources_data)


@app.route('/resources/create', methods=['POST'])
def create_resource():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    tags_input = request.form.get('tags', '')

    new_resource = ResourceDB(
        resource_id=str(uuid.uuid4())[:8],
        title=request.form.get('title'),
        course=request.form.get('course'),
        uploader_roll=user_roll,
        resource_type=request.form.get('resource_type'),
        url=request.form.get('url'),
        description=request.form.get('description', ''),
        tags=','.join([t.strip() for t in tags_input.split(',') if t.strip()])
    )
    db.session.add(new_resource)
    db.session.commit()

    flash('Resource shared successfully!', 'success')
    return redirect(url_for('resources'))


@app.route('/resources/<resource_id>/like', methods=['POST'])
def like_resource(resource_id):
    if 'user_roll' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    user_roll = session['user_roll']
    resource = ResourceDB.query.get(resource_id)

    if resource:
        likes = resource.likes.split(',') if resource.likes else []
        likes = [l for l in likes if l]  # Remove empty strings

        if user_roll in likes:
            likes.remove(user_roll)
            liked = False
        else:
            likes.append(user_roll)
            liked = True

        resource.likes = ','.join(likes)
        db.session.commit()

        return jsonify({'success': True, 'liked': liked, 'like_count': len(likes)})

    return jsonify({'error': 'Resource not found'}), 404


@app.route('/resources/<resource_id>/view', methods=['POST'])
def view_resource(resource_id):
    if 'user_roll' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    resource = ResourceDB.query.get(resource_id)

    if resource:
        resource.views += 1
        db.session.commit()
        return jsonify({'success': True, 'views': resource.views})

    return jsonify({'error': 'Resource not found'}), 404


@app.route('/resources/<resource_id>/delete', methods=['POST'])
def delete_resource(resource_id):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    resource = ResourceDB.query.get(resource_id)

    if resource and resource.uploader_roll == user_roll:
        db.session.delete(resource)
        db.session.commit()
        flash('Resource deleted successfully!', 'success')
    else:
        flash('Cannot delete resource', 'error')

    return redirect(url_for('resources'))


# ==================== FRIENDS ROUTES ====================

@app.route('/friends')
def friends():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    friendships = FriendshipDB.query.filter_by(user_roll=user_roll).all()
    my_friends = []
    for f in friendships:
        friend = StudentDB.query.get(f.friend_roll)
        if friend:
            my_friends.append(friend.to_dict())

    return render_template('friends.html', student=student.to_dict(), my_friends=my_friends)


@app.route('/friends/add/<friend_roll>', methods=['POST'])
def add_friend(friend_roll):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']

    if user_roll == friend_roll:
        flash('Cannot add yourself!', 'error')
        return redirect(url_for('skills'))

    existing = FriendshipDB.query.filter_by(user_roll=user_roll, friend_roll=friend_roll).first()

    if not existing:
        friendship = FriendshipDB(user_roll=user_roll, friend_roll=friend_roll)
        db.session.add(friendship)
        db.session.commit()
        flash('Friend added successfully!', 'success')
    else:
        flash('Already friends!', 'info')

    return redirect(url_for('skills'))


@app.route('/friends/remove/<friend_roll>', methods=['POST'])
def remove_friend(friend_roll):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']

    friendship = FriendshipDB.query.filter_by(user_roll=user_roll, friend_roll=friend_roll).first()

    if friendship:
        db.session.delete(friendship)
        db.session.commit()
        flash('Friend removed successfully!', 'success')

    return redirect(url_for('friends'))


# ==================== MESSAGES ROUTES ====================

@app.route('/friends/<friend_roll>/message', methods=['POST'])
def send_message(friend_roll):
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    message_text = request.form.get('message')

    if message_text:
        message = MessageDB(
            from_roll=user_roll,
            to_roll=friend_roll,
            message=message_text
        )
        db.session.add(message)
        db.session.commit()
        flash('Message sent!', 'success')

    return redirect(url_for('friends'))


@app.route('/friends/messages')
def view_messages():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    user_roll = session['user_roll']
    student = StudentDB.query.get(user_roll)

    messages = MessageDB.query.filter(
        (MessageDB.from_roll == user_roll) | (MessageDB.to_roll == user_roll)
    ).order_by(MessageDB.timestamp.desc()).all()

    messages_data = []
    for m in messages:
        msg = m.to_dict()
        msg['from_student'] = StudentDB.query.get(m.from_roll).to_dict() if StudentDB.query.get(m.from_roll) else None
        msg['to_student'] = StudentDB.query.get(m.to_roll).to_dict() if StudentDB.query.get(m.to_roll) else None
        messages_data.append(msg)

    return render_template('messages.html', student=student.to_dict(), messages=messages_data)


# ==================== SEARCH ROUTE ====================

@app.route('/search')
def search():
    if 'user_roll' not in session:
        return redirect(url_for('login'))

    query = request.args.get('q', '')
    filter_type = request.args.get('type', 'name')

    student = StudentDB.query.get(session['user_roll'])
    all_students = get_all_students_dict()
    results = []

    if query:
        if filter_type == 'name':
            results = search_students_by_name(all_students, query)
        elif filter_type == 'course':
            results = search_students_by_course(all_students, query)

    return render_template('search.html', student=student.to_dict(), query=query, filter_type=filter_type,
                           results=results)


# ==================== RUN APP ====================

if __name__ == '__main__':
    app.run(debug=True, port=5000)