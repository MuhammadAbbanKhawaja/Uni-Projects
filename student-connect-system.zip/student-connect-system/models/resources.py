from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


# ==================== STUDENT MODEL ====================
class StudentDB(db.Model):
    __tablename__ = 'students'

    roll_number = db.Column(db.String(50), primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    department = db.Column(db.String(20), nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    courses = db.Column(db.Text, default='')  # Comma-separated
    skills = db.Column(db.Text, default='')  # Comma-separated
    bio = db.Column(db.Text, default='')
    phone = db.Column(db.String(20), default='')
    profile_picture = db.Column(db.Text, default='')  # Base64 image
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'roll_number': self.roll_number,
            'name': self.name,
            'email': self.email,
            'department': self.department,
            'semester': self.semester,
            'bio': self.bio,
            'phone': self.phone,
            'courses': self.courses.split(',') if self.courses else [],  # Return as list
            'skills': self.skills.split(',') if self.skills else [],  # Return as list
            'profile_picture': self.profile_picture
        }


# ==================== FRIENDSHIP MODEL ====================
class FriendshipDB(db.Model):
    __tablename__ = 'friendships'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_roll = db.Column(db.String(50), db.ForeignKey('students.roll_number'), nullable=False)
    friend_roll = db.Column(db.String(50), db.ForeignKey('students.roll_number'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# ==================== MESSAGE MODEL ====================
class MessageDB(db.Model):
    __tablename__ = 'messages'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    from_roll = db.Column(db.String(50), db.ForeignKey('students.roll_number'), nullable=False)
    to_roll = db.Column(db.String(50), db.ForeignKey('students.roll_number'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    read = db.Column(db.Boolean, default=False)

    def to_dict(self):
        return {
            'id': self.id,
            'from': self.from_roll,
            'to': self.to_roll,
            'message': self.message,
            'timestamp': self.timestamp.isoformat() if self.timestamp else '',
            'read': self.read
        }


# ==================== STUDY SESSION MODEL ====================
class StudySessionDB(db.Model):
    __tablename__ = 'study_sessions'

    session_id = db.Column(db.String(20), primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    course = db.Column(db.String(100), nullable=False)
    organizer_roll = db.Column(db.String(50), db.ForeignKey('students.roll_number'), nullable=False)
    date = db.Column(db.String(20), nullable=False)
    time = db.Column(db.String(10), nullable=False)
    location = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default='')
    max_participants = db.Column(db.Integer, default=10)
    participants = db.Column(db.Text, default='')  # Comma-separated
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return {
            'session_id': self.session_id,
            'title': self.title,
            'course': self.course,
            'organizer_roll': self.organizer_roll,
            'date': self.date,
            'time': self.time,
            'location': self.location,
            'description': self.description,
            'max_participants': self.max_participants,
            'participants': self.participants.split(',') if self.participants else [],
            'created_at': self.created_at.isoformat() if self.created_at else '',
            'is_active': self.is_active
        }


# ==================== RESOURCE MODEL ====================
class ResourceDB(db.Model):
    __tablename__ = 'resources'

    resource_id = db.Column(db.String(20), primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    course = db.Column(db.String(100), nullable=False)
    uploader_roll = db.Column(db.String(50), db.ForeignKey('students.roll_number'), nullable=False)
    resource_type = db.Column(db.String(50), nullable=False)
    url = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text, default='')
    tags = db.Column(db.Text, default='')  # Comma-separated
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    views = db.Column(db.Integer, default=0)
    likes = db.Column(db.Text, default='')  # Comma-separated roll numbers who liked

    def to_dict(self):
        return {
            'resource_id': self.resource_id,
            'title': self.title,
            'course': self.course,
            'uploader_roll': self.uploader_roll,
            'resource_type': self.resource_type,
            'url': self.url,
            'description': self.description,
            'tags': self.tags,
            'likes': self.likes,  # Keep as string
            'views': self.views,
            'uploaded_at': self.uploaded_at.isoformat() if self.uploaded_at else ''
        }


# ==================== CONNECTION/GRAPH MODEL ====================
class ConnectionDB(db.Model):
    __tablename__ = 'connections'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    student1_roll = db.Column(db.String(50), nullable=False)
    student2_roll = db.Column(db.String(50), nullable=False)
    shared_courses = db.Column(db.Text, default='')  # Comma-separated
    created_at = db.Column(db.DateTime, default=datetime.utcnow)