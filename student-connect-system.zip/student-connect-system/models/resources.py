from datetime import datetime
import uuid


class Resource:
    """Resource model for sharing study materials"""

    def __init__(self, title, course, uploader_roll, resource_type, url, description="", tags=None):
        self.resource_id = str(uuid.uuid4())[:8]
        self.title = title
        self.course = course
        self.uploader_roll = uploader_roll
        self.resource_type = resource_type  # 'notes', 'link', 'video', 'document'
        self.url = url
        self.description = description
        self.tags = tags if tags else []
        self.uploaded_at = datetime.now().isoformat()
        self.views = 0
        self.likes = []

    def to_dict(self):
        """Convert resource to dictionary"""
        return {
            'resource_id': self.resource_id,
            'title': self.title,
            'course': self.course,
            'uploader_roll': self.uploader_roll,
            'resource_type': self.resource_type,
            'url': self.url,
            'description': self.description,
            'tags': self.tags,
            'uploaded_at': self.uploaded_at,
            'views': self.views,
            'likes': self.likes
        }

    @classmethod
    def from_dict(cls, data):
        """Create resource from dictionary"""
        resource = cls(
            title=data.get('title'),
            course=data.get('course'),
            uploader_roll=data.get('uploader_roll'),
            resource_type=data.get('resource_type'),
            url=data.get('url'),
            description=data.get('description', ''),
            tags=data.get('tags', [])
        )
        resource.resource_id = data.get('resource_id')
        resource.uploaded_at = data.get('uploaded_at')
        resource.views = data.get('views', 0)
        resource.likes = data.get('likes', [])
        return resource

    def increment_views(self):
        """Increment view count"""
        self.views += 1

    def like(self, roll_number):
        """Like resource"""
        if roll_number not in self.likes:
            self.likes.append(roll_number)
            return True
        return False

    def unlike(self, roll_number):
        """Unlike resource"""
        if roll_number in self.likes:
            self.likes.remove(roll_number)
            return True
        return False

    def is_liked_by(self, roll_number):
        """Check if liked by user"""
        return roll_number in self.likes

    def get_like_count(self):
        """Get number of likes"""
        return len(self.likes)

    def add_tag(self, tag):
        """Add tag"""
        if tag not in self.tags:
            self.tags.append(tag)
            return True
        return False

    def __str__(self):
        return f"Resource({self.title}, {self.course}, {self.resource_type})"