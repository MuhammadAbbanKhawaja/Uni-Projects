from datetime import datetime
import uuid


class StudySession:
    """Study Session model for scheduling study sessions"""

    def __init__(self, title, course, organizer_roll, date, time, location, description="", max_participants=10):
        self.session_id = str(uuid.uuid4())[:8]
        self.title = title
        self.course = course
        self.organizer_roll = organizer_roll
        self.date = date  # Format: YYYY-MM-DD
        self.time = time  # Format: HH:MM
        self.location = location
        self.description = description
        self.max_participants = max_participants
        self.participants = [organizer_roll]
        self.created_at = datetime.now().isoformat()
        self.is_active = True

    def to_dict(self):
        """Convert session to dictionary"""
        return {
            'session_id': self.session_id,
            'title': self.title,
            'course': self.course,
            'organizer_roll': self.organizer_roll,
            'date': self.date,
            'time': self.time,
            'location': self.location,
            'description': self.description,
            'max_participants': self.max_participants,
            'participants': self.participants,
            'created_at': self.created_at,
            'is_active': self.is_active
        }

    @classmethod
    def from_dict(cls, data):
        """Create session from dictionary"""
        session = cls(
            title=data.get('title'),
            course=data.get('course'),
            organizer_roll=data.get('organizer_roll'),
            date=data.get('date'),
            time=data.get('time'),
            location=data.get('location'),
            description=data.get('description', ''),
            max_participants=data.get('max_participants', 10)
        )
        session.session_id = data.get('session_id')
        session.participants = data.get('participants', [])
        session.created_at = data.get('created_at')
        session.is_active = data.get('is_active', True)
        return session

    def get_datetime(self):
        """Get session datetime as datetime object"""
        try:
            dt_str = f"{self.date} {self.time}"
            return datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
        except:
            return None

    def get_timestamp(self):
        """Get session timestamp for priority queue"""
        dt = self.get_datetime()
        return dt.timestamp() if dt else 0

    def is_full(self):
        """Check if session is full"""
        return len(self.participants) >= self.max_participants

    def join_session(self, roll_number):
        """Add participant to session"""
        if self.is_full():
            return False, "Session is full"

        if roll_number in self.participants:
            return False, "Already joined"

        self.participants.append(roll_number)
        return True, "Joined successfully"

    def leave_session(self, roll_number):
        """Remove participant from session"""
        if roll_number == self.organizer_roll:
            return False, "Organizer cannot leave"

        if roll_number not in self.participants:
            return False, "Not a participant"

        self.participants.remove(roll_number)
        return True, "Left successfully"

    def is_organizer(self, roll_number):
        """Check if user is organizer"""
        return roll_number == self.organizer_roll

    def is_participant(self, roll_number):
        """Check if user is participant"""
        return roll_number in self.participants

    def is_upcoming(self):
        """Check if session is in the future - FIXED!"""
        session_dt = self.get_datetime()
        if not session_dt:
            # If date parsing fails, consider it upcoming
            return True

        # Add buffer time (session is upcoming if within next 365 days)
        return session_dt > datetime.now()

    def __str__(self):
        return f"StudySession({self.title}, {self.date} {self.time}, {len(self.participants)} participants)"