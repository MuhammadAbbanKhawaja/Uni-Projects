from datetime import datetime
import uuid


class StudyGroup:
    """Study Group model for managing study groups"""

    def __init__(self, name, course, creator_roll, description="", max_members=10):
        self.group_id = str(uuid.uuid4())[:8]  # Short unique ID
        self.name = name
        self.course = course
        self.creator_roll = creator_roll
        self.description = description
        self.max_members = max_members
        self.members = [creator_roll]  # Creator is first member
        self.pending_requests = []  # Queue of join requests
        self.created_at = datetime.now().isoformat()
        self.is_active = True

    def to_dict(self):
        """Convert group to dictionary"""
        return {
            'group_id': self.group_id,
            'name': self.name,
            'course': self.course,
            'creator_roll': self.creator_roll,
            'description': self.description,
            'max_members': self.max_members,
            'members': self.members,
            'pending_requests': self.pending_requests,
            'created_at': self.created_at,
            'is_active': self.is_active
        }

    @classmethod
    def from_dict(cls, data):
        """Create group from dictionary"""
        group = cls(
            name=data.get('name'),
            course=data.get('course'),
            creator_roll=data.get('creator_roll'),
            description=data.get('description', ''),
            max_members=data.get('max_members', 10)
        )
        group.group_id = data.get('group_id')
        group.members = data.get('members', [])
        group.pending_requests = data.get('pending_requests', [])
        group.created_at = data.get('created_at')
        group.is_active = data.get('is_active', True)
        return group

    def is_full(self):
        """Check if group has reached max capacity"""
        return len(self.members) >= self.max_members

    def add_member(self, roll_number):
        """Add member to group"""
        if self.is_full():
            return False, "Group is full"

        if roll_number in self.members:
            return False, "Already a member"

        self.members.append(roll_number)

        # Remove from pending if exists
        if roll_number in self.pending_requests:
            self.pending_requests.remove(roll_number)

        return True, "Member added successfully"

    def remove_member(self, roll_number):
        """Remove member from group"""
        if roll_number == self.creator_roll:
            return False, "Cannot remove group creator"

        if roll_number not in self.members:
            return False, "Not a member"

        self.members.remove(roll_number)
        return True, "Member removed successfully"

    def add_join_request(self, roll_number):
        """Add join request to queue"""
        if roll_number in self.members:
            return False, "Already a member"

        if roll_number in self.pending_requests:
            return False, "Request already pending"

        if self.is_full():
            return False, "Group is full"

        self.pending_requests.append(roll_number)
        return True, "Request submitted"

    def approve_request(self, roll_number):
        """Approve join request"""
        if roll_number not in self.pending_requests:
            return False, "No pending request found"

        return self.add_member(roll_number)

    def reject_request(self, roll_number):
        """Reject join request"""
        if roll_number in self.pending_requests:
            self.pending_requests.remove(roll_number)
            return True, "Request rejected"
        return False, "No pending request found"

    def is_creator(self, roll_number):
        """Check if user is group creator"""
        return roll_number == self.creator_roll

    def is_member(self, roll_number):
        """Check if user is a member"""
        return roll_number in self.members

    def __str__(self):
        return f"StudyGroup({self.name}, {self.course}, {len(self.members)} members)"