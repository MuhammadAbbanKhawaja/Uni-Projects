from datetime import datetime


class Student:
    """Student model for storing student information"""

    def __init__(self, roll_number, name, email, password, department, semester, courses=None, skills=None,
                 interests=None):
        self.roll_number = roll_number
        self.name = name
        self.email = email
        self.password = password  # In production, this should be hashed!
        self.department = department
        self.semester = semester
        self.courses = courses if courses else []
        self.skills = skills if skills else []
        self.interests = interests if interests else []
        self.created_at = datetime.now().isoformat()
        self.bio = ""
        self.phone = ""
        self.cgpa = 0.0

    def to_dict(self):
        """Convert student object to dictionary"""
        return {
            'roll_number': self.roll_number,
            'name': self.name,
            'email': self.email,
            'password': self.password,
            'department': self.department,
            'semester': self.semester,
            'courses': self.courses,
            'skills': self.skills,
            'interests': self.interests,
            'created_at': self.created_at,
            'bio': self.bio,
            'phone': self.phone,
            'cgpa': self.cgpa
        }

    @classmethod
    def from_dict(cls, data):
        """Create student object from dictionary"""
        student = cls(
            roll_number=data.get('roll_number'),
            name=data.get('name'),
            email=data.get('email'),
            password=data.get('password'),
            department=data.get('department'),
            semester=data.get('semester'),
            courses=data.get('courses', []),
            skills=data.get('skills', []),
            interests=data.get('interests', [])
        )
        student.created_at = data.get('created_at', datetime.now().isoformat())
        student.bio = data.get('bio', '')
        student.phone = data.get('phone', '')
        student.cgpa = data.get('cgpa', 0.0)
        return student

    def add_course(self, course):
        """Add a course to student's courses"""
        if course not in self.courses:
            self.courses.append(course)
            return True
        return False

    def remove_course(self, course):
        """Remove a course from student's courses"""
        if course in self.courses:
            self.courses.remove(course)
            return True
        return False

    def add_skill(self, skill):
        """Add a skill"""
        if skill not in self.skills:
            self.skills.append(skill)
            return True
        return False

    def remove_skill(self, skill):
        """Remove a skill"""
        if skill in self.skills:
            self.skills.remove(skill)
            return True
        return False

    def __str__(self):
        return f"Student({self.roll_number}, {self.name}, {self.department})"

    def __repr__(self):
        return self.__str__()