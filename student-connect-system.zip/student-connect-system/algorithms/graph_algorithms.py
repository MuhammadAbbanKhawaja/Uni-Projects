from collections import deque


def bfs(graph, start_vertex):
    """
    Breadth-First Search - O(V + E)
    Used for: Finding shortest path, level-wise traversal

    Args:
        graph: Graph object
        start_vertex: Starting node (roll number)

    Returns:
        Dictionary with distances and paths from start vertex
    """
    visited = set()
    queue = deque([(start_vertex, 0)])  # (vertex, distance)
    distances = {start_vertex: 0}
    paths = {start_vertex: [start_vertex]}

    while queue:
        vertex, dist = queue.popleft()

        if vertex in visited:
            continue

        visited.add(vertex)

        # Visit all neighbors
        for neighbor in graph.get_neighbors(vertex):
            if neighbor not in visited:
                queue.append((neighbor, dist + 1))

                if neighbor not in distances:
                    distances[neighbor] = dist + 1
                    paths[neighbor] = paths[vertex] + [neighbor]

    return {
        'visited': list(visited),
        'distances': distances,
        'paths': paths
    }


def dfs(graph, start_vertex):
    """
    Depth-First Search - O(V + E)
    Used for: Finding all reachable nodes, cycle detection

    Args:
        graph: Graph object
        start_vertex: Starting node (roll number)

    Returns:
        List of visited vertices in DFS order
    """
    visited = set()
    result = []

    def dfs_helper(vertex):
        visited.add(vertex)
        result.append(vertex)

        for neighbor in graph.get_neighbors(vertex):
            if neighbor not in visited:
                dfs_helper(neighbor)

    dfs_helper(start_vertex)
    return result


def find_mutual_connections(graph, student1, student2):
    """
    Find mutual connections between two students
    Time Complexity: O(min(d1, d2)) where d is degree

    Args:
        graph: Graph object
        student1: Roll number of first student
        student2: Roll number of second student

    Returns:
        List of mutual connections (roll numbers)
    """
    connections1 = set(graph.get_neighbors(student1))
    connections2 = set(graph.get_neighbors(student2))

    mutual = connections1 & connections2
    return list(mutual)


def suggest_connections(graph, student_roll, max_suggestions=5):
    """
    Suggest new connections based on mutual friends
    Uses Friends-of-Friends algorithm
    Time Complexity: O(V * E)

    Args:
        graph: Graph object
        student_roll: Roll number of student
        max_suggestions: Maximum number of suggestions

    Returns:
        List of suggested connections with scores
    """
    direct_connections = set(graph.get_neighbors(student_roll))
    suggestions = {}

    # For each friend, look at their friends
    for friend in direct_connections:
        for friend_of_friend in graph.get_neighbors(friend):
            # Skip if it's the student themselves or already connected
            if friend_of_friend == student_roll or friend_of_friend in direct_connections:
                continue

            # Count mutual friends
            if friend_of_friend not in suggestions:
                suggestions[friend_of_friend] = {
                    'roll_number': friend_of_friend,
                    'mutual_friends': 0,
                    'common_friends': []
                }

            suggestions[friend_of_friend]['mutual_friends'] += 1
            suggestions[friend_of_friend]['common_friends'].append(friend)

    # Sort by number of mutual friends
    sorted_suggestions = sorted(
        suggestions.values(),
        key=lambda x: x['mutual_friends'],
        reverse=True
    )

    return sorted_suggestions[:max_suggestions]


def shortest_path(graph, start, end):
    """
    Find shortest path between two students using BFS
    Time Complexity: O(V + E)

    Args:
        graph: Graph object
        start: Starting student roll number
        end: Target student roll number

    Returns:
        Shortest path as list of roll numbers, or None if no path
    """
    if start == end:
        return [start]

    visited = set()
    queue = deque([(start, [start])])

    while queue:
        vertex, path = queue.popleft()

        if vertex in visited:
            continue

        visited.add(vertex)

        for neighbor in graph.get_neighbors(vertex):
            if neighbor == end:
                return path + [neighbor]

            if neighbor not in visited:
                queue.append((neighbor, path + [neighbor]))

    return None  # No path found


def find_all_paths(graph, start, end, max_length=5):
    """
    Find all paths between two students (up to max_length)
    Time Complexity: O(V!) in worst case

    Args:
        graph: Graph object
        start: Starting student roll number
        end: Target student roll number
        max_length: Maximum path length to consider

    Returns:
        List of all paths
    """
    all_paths = []

    def dfs_paths(current, target, path, visited):
        if len(path) > max_length:
            return

        if current == target:
            all_paths.append(path[:])
            return

        visited.add(current)

        for neighbor in graph.get_neighbors(current):
            if neighbor not in visited:
                path.append(neighbor)
                dfs_paths(neighbor, target, path, visited)
                path.pop()

        visited.remove(current)

    dfs_paths(start, end, [start], set())
    return all_paths


def detect_communities(graph, min_size=3):
    """
    Detect communities (groups of closely connected students)
    Simple connected components algorithm
    Time Complexity: O(V + E)

    Args:
        graph: Graph object
        min_size: Minimum community size

    Returns:
        List of communities (each community is a list of roll numbers)
    """
    visited = set()
    communities = []

    def explore_community(start):
        community = []
        queue = deque([start])

        while queue:
            vertex = queue.popleft()

            if vertex in visited:
                continue

            visited.add(vertex)
            community.append(vertex)

            for neighbor in graph.get_neighbors(vertex):
                if neighbor not in visited:
                    queue.append(neighbor)

        return community

    # Find all connected components
    for vertex in graph.get_all_vertices():
        if vertex not in visited:
            community = explore_community(vertex)
            if len(community) >= min_size:
                communities.append(community)

    return communities


def calculate_centrality(graph):
    """
    Calculate degree centrality for all students
    (How well-connected each student is)
    Time Complexity: O(V)

    Args:
        graph: Graph object

    Returns:
        Dictionary mapping roll numbers to centrality scores
    """
    all_vertices = graph.get_all_vertices()
    if not all_vertices:
        return {}

    max_possible = len(all_vertices) - 1
    centrality = {}

    for vertex in all_vertices:
        degree = graph.degree(vertex)
        # Normalize to 0-1 range
        centrality[vertex] = degree / max_possible if max_possible > 0 else 0

    return centrality


def find_influencers(graph, top_n=5):
    """
    Find most influential students (highest degree centrality)
    Time Complexity: O(V log V)

    Args:
        graph: Graph object
        top_n: Number of top influencers to return

    Returns:
        List of (roll_number, connection_count) tuples
    """
    centrality = calculate_centrality(graph)

    # Sort by centrality score
    sorted_students = sorted(
        centrality.items(),
        key=lambda x: x[1],
        reverse=True
    )

    return sorted_students[:top_n]


def is_connected(graph):
    """
    Check if the entire graph is connected
    Time Complexity: O(V + E)

    Args:
        graph: Graph object

    Returns:
        True if graph is connected, False otherwise
    """
    vertices = graph.get_all_vertices()
    if not vertices:
        return True

    visited = dfs(graph, vertices[0])
    return len(visited) == len(vertices)