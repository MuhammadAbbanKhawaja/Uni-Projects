def bubble_sort(arr, key=None, reverse=False):
    """
    Bubble Sort - O(n²)
    Simple but inefficient for large datasets

    Args:
        arr: List to sort
        key: Function to extract comparison key
        reverse: Sort in descending order if True

    Returns:
        Sorted list
    """
    arr = arr.copy()
    n = len(arr)

    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            val1 = key(arr[j]) if key else arr[j]
            val2 = key(arr[j + 1]) if key else arr[j + 1]

            if (val1 > val2 and not reverse) or (val1 < val2 and reverse):
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True

        if not swapped:
            break

    return arr


def quick_sort(arr, key=None, reverse=False):
    """
    Quick Sort - O(n log n) average
    Efficient for most cases

    Args:
        arr: List to sort
        key: Function to extract comparison key
        reverse: Sort in descending order if True

    Returns:
        Sorted list
    """
    if len(arr) <= 1:
        return arr

    pivot = arr[len(arr) // 2]
    pivot_val = key(pivot) if key else pivot

    left = []
    middle = []
    right = []

    for item in arr:
        item_val = key(item) if key else item

        if item_val < pivot_val:
            left.append(item)
        elif item_val > pivot_val:
            right.append(item)
        else:
            middle.append(item)

    if reverse:
        return quick_sort(right, key, reverse) + middle + quick_sort(left, key, reverse)
    else:
        return quick_sort(left, key, reverse) + middle + quick_sort(right, key, reverse)


def merge_sort(arr, key=None, reverse=False):
    """
    Merge Sort - O(n log n)
    Stable sort, good for linked lists

    Args:
        arr: List to sort
        key: Function to extract comparison key
        reverse: Sort in descending order if True

    Returns:
        Sorted list
    """
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = merge_sort(arr[:mid], key, reverse)
    right = merge_sort(arr[mid:], key, reverse)

    return _merge(left, right, key, reverse)


def _merge(left, right, key=None, reverse=False):
    """Merge helper for merge sort"""
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        left_val = key(left[i]) if key else left[i]
        right_val = key(right[j]) if key else right[j]

        if (left_val <= right_val and not reverse) or (left_val >= right_val and reverse):
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])

    return result


def sort_students_by_name(students, reverse=False):
    """
    Sort students by name
    Time Complexity: O(n log n)
    """
    return quick_sort(students, key=lambda s: s.get('name', '').lower(), reverse=reverse)


def sort_students_by_semester(students, reverse=False):
    """
    Sort students by semester
    Time Complexity: O(n log n)
    """
    return quick_sort(students, key=lambda s: s.get('semester', 0), reverse=reverse)


def sort_students_by_cgpa(students, reverse=True):
    """
    Sort students by CGPA (highest first by default)
    Time Complexity: O(n log n)
    """
    return quick_sort(students, key=lambda s: s.get('cgpa', 0.0), reverse=reverse)


def sort_students_by_connections(students, graph, reverse=True):
    """
    Sort students by number of connections (most connected first)
    Time Complexity: O(n log n)

    Args:
        students: List of student dictionaries
        graph: Graph object containing connections
        reverse: Most connected first if True
    """

    def connection_count(student):
        roll = student.get('roll_number')
        return graph.degree(roll) if roll else 0

    return quick_sort(students, key=connection_count, reverse=reverse)


def sort_sessions_by_date(sessions):
    """Sort sessions by datetime (earliest first)"""
    return sorted(sessions, key=lambda s: s.get_timestamp() if s.get_datetime() else 0)

def sort_resources_by_date(resources):
    """Sort resources by upload date (newest first)"""
    return sorted(resources, key=lambda r: r.uploaded_at, reverse=True)


def rank_matches(students, current_student, skills_weight=0.4, courses_weight=0.6):
    """
    Rank potential connections based on skill and course similarity
    Time Complexity: O(n log n)

    Args:
        students: List of all students
        current_student: Current user's student dictionary
        skills_weight: Weight for skill matching (0-1)
        courses_weight: Weight for course matching (0-1)

    Returns:
        List of students sorted by match score (highest first)
    """
    current_skills = set(s.lower() for s in current_student.get('skills', []))
    current_courses = set(c.lower() for c in current_student.get('courses', []))
    current_roll = current_student.get('roll_number')

    def calculate_match_score(student):
        if student.get('roll_number') == current_roll:
            return 0

        student_skills = set(s.lower() for s in student.get('skills', []))
        student_courses = set(c.lower() for c in student.get('courses', []))

        # Calculate Jaccard similarity
        skill_score = 0
        if current_skills or student_skills:
            skill_intersection = len(current_skills & student_skills)
            skill_union = len(current_skills | student_skills)
            skill_score = skill_intersection / skill_union if skill_union > 0 else 0

        course_score = 0
        if current_courses or student_courses:
            course_intersection = len(current_courses & student_courses)
            course_union = len(current_courses | student_courses)
            course_score = course_intersection / course_union if course_union > 0 else 0

        # Weighted total score
        total_score = (skills_weight * skill_score) + (courses_weight * course_score)
        return total_score

    # Filter out current student and sort by match score
    other_students = [s for s in students if s.get('roll_number') != current_roll]
    return quick_sort(other_students, key=calculate_match_score, reverse=True)