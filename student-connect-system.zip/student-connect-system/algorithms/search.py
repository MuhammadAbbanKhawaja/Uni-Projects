def linear_search(arr, target, key=None):
    """
    Linear Search - O(n)
    Used for: Searching in unsorted data

    Args:
        arr: List of items
        target: Value to search for
        key: Function to extract comparison key from item

    Returns:
        Index of item if found, -1 otherwise
    """
    for i, item in enumerate(arr):
        value = key(item) if key else item
        if value == target:
            return i
    return -1


def binary_search(arr, target, key=None):
    """
    Binary Search - O(log n)
    Used for: Searching in sorted data
    Requires: Array must be sorted

    Args:
        arr: Sorted list of items
        target: Value to search for
        key: Function to extract comparison key from item

    Returns:
        Index of item if found, -1 otherwise
    """
    left, right = 0, len(arr) - 1

    while left <= right:
        mid = (left + right) // 2
        mid_value = key(arr[mid]) if key else arr[mid]

        if mid_value == target:
            return mid
        elif mid_value < target:
            left = mid + 1
        else:
            right = mid - 1

    return -1


def search_students_by_name(students, name_query):
    """
    Search students by name (case-insensitive, partial match)
    Time Complexity: O(n)

    Args:
        students: List of student dictionaries
        name_query: Name to search for

    Returns:
        List of matching students
    """
    name_query = name_query.lower()
    results = []

    for student in students:
        student_name = student.get('name', '').lower()
        if name_query in student_name:
            results.append(student)

    return results


def search_students_by_course(students, course_name):
    """
    Search students enrolled in a specific course
    Time Complexity: O(n)

    Args:
        students: List of student dictionaries
        course_name: Course to search for

    Returns:
        List of students taking that course
    """
    course_name = course_name.lower()
    results = []

    for student in students:
        courses = [c.lower() for c in student.get('courses', [])]
        if course_name in courses:
            results.append(student)

    return results


def search_students_by_skill(students, skill):
    """
    Search students with a specific skill
    Time Complexity: O(n)

    Args:
        students: List of student dictionaries
        skill: Skill to search for

    Returns:
        List of students with that skill
    """
    skill = skill.lower()
    results = []

    for student in students:
        skills = [s.lower() for s in student.get('skills', [])]
        if skill in skills:
            results.append(student)

    return results


def search_students_by_department(students, department):
    """
    Search students by department
    Time Complexity: O(n)

    Args:
        students: List of student dictionaries
        department: Department to filter by

    Returns:
        List of students in that department
    """
    department = department.lower()
    results = []

    for student in students:
        if student.get('department', '').lower() == department:
            results.append(student)

    return results


def advanced_search(students, filters):
    """
    Advanced search with multiple filters
    Time Complexity: O(n * m) where m is number of filters

    Args:
        students: List of student dictionaries
        filters: Dictionary of filters
            Example: {
                'name': 'ali',
                'department': 'CS',
                'semester': 5,
                'course': 'Data Structures'
            }

    Returns:
        List of students matching all filters
    """
    results = students.copy()

    # Filter by name
    if 'name' in filters and filters['name']:
        name_query = filters['name'].lower()
        results = [s for s in results if name_query in s.get('name', '').lower()]

    # Filter by department
    if 'department' in filters and filters['department']:
        dept = filters['department'].lower()
        results = [s for s in results if s.get('department', '').lower() == dept]

    # Filter by semester
    if 'semester' in filters and filters['semester']:
        sem = filters['semester']
        results = [s for s in results if s.get('semester') == sem]

    # Filter by course
    if 'course' in filters and filters['course']:
        course = filters['course'].lower()
        results = [s for s in results
                   if any(course in c.lower() for c in s.get('courses', []))]

    # Filter by skill
    if 'skill' in filters and filters['skill']:
        skill = filters['skill'].lower()
        results = [s for s in results
                   if any(skill in sk.lower() for sk in s.get('skills', []))]

    return results


def fuzzy_search(arr, query, key=None, threshold=0.6):
    """
    Fuzzy search for approximate string matching
    Time Complexity: O(n * m) where m is average string length

    Args:
        arr: List of items
        query: Search query
        key: Function to extract string from item
        threshold: Similarity threshold (0-1)

    Returns:
        List of matches with similarity scores
    """

    def similarity(s1, s2):
        """Calculate simple character overlap similarity"""
        s1, s2 = s1.lower(), s2.lower()
        matches = sum(1 for c in s1 if c in s2)
        return matches / max(len(s1), len(s2))

    query = query.lower()
    results = []

    for item in arr:
        text = key(item) if key else str(item)
        score = similarity(query, text)

        if score >= threshold:
            results.append({
                'item': item,
                'score': score
            })

    # Sort by similarity score (descending)
    results.sort(key=lambda x: x['score'], reverse=True)

    return results