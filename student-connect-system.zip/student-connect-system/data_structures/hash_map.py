class HashMap:
    """
    Custom HashMap implementation for storing student data
    Key: Roll Number (String)
    Value: Student Dictionary
    Time Complexity: O(1) for insert, get, delete operations
    """

    def __init__(self, size=100):
        self.size = size
        self.table = [[] for _ in range(self.size)]
        self.count = 0

    def _hash(self, key):
        """Hash function to convert roll number to index"""
        hash_value = 0
        for char in str(key):
            hash_value += ord(char)
        return hash_value % self.size

    def insert(self, key, value):
        """Insert student data - O(1) average"""
        index = self._hash(key)

        # Check if key already exists (update)
        for i, (k, v) in enumerate(self.table[index]):
            if k == key:
                self.table[index][i] = (key, value)
                return True

        # Insert new key-value pair
        self.table[index].append((key, value))
        self.count += 1
        return True

    def get(self, key):
        """Get student data by roll number - O(1) average"""
        index = self._hash(key)

        for k, v in self.table[index]:
            if k == key:
                return v

        return None

    def delete(self, key):
        """Delete student data - O(1) average"""
        index = self._hash(key)

        for i, (k, v) in enumerate(self.table[index]):
            if k == key:
                self.table[index].pop(i)
                self.count -= 1
                return True

        return False

    def get_all(self):
        """Get all students - O(n)"""
        all_items = []
        for bucket in self.table:
            for key, value in bucket:
                all_items.append(value)
        return all_items

    def exists(self, key):
        """Check if student exists - O(1) average"""
        return self.get(key) is not None

    def size(self):
        """Get number of students"""
        return self.count

    def __str__(self):
        """String representation for debugging"""
        return f"HashMap(size={self.count})"