class TreeNode:
    """Node for Tree structure"""

    def __init__(self, data, node_type="folder"):
        self.data = data  # Course name, topic, or resource
        self.node_type = node_type  # "folder" or "file"
        self.children = []
        self.parent = None

    def add_child(self, child_node):
        """Add child node"""
        child_node.parent = self
        self.children.append(child_node)

    def remove_child(self, child_node):
        """Remove child node"""
        self.children = [c for c in self.children if c != child_node]


class Tree:
    """
    Tree implementation for organizing resources hierarchically
    Structure: Root -> Courses -> Topics -> Resources
    Example: Root -> "Data Structures" -> "Graphs" -> "lecture_notes.pdf"
    """

    def __init__(self, root_data="Resources"):
        self.root = TreeNode(root_data, "folder")

    def add_node(self, parent_path, node_data, node_type="folder"):
        """
        Add node to tree - O(h) where h is height
        parent_path: list like ["Data Structures", "Graphs"]
        """
        parent_node = self._find_node(self.root, parent_path)

        if parent_node:
            new_node = TreeNode(node_data, node_type)
            parent_node.add_child(new_node)
            return True

        return False

    def _find_node(self, current, path):
        """Find node by path - O(h)"""
        if not path:
            return current

        for child in current.children:
            if child.data == path[0]:
                return self._find_node(child, path[1:])

        return None

    def get_resources_by_course(self, course_name):
        """Get all resources for a course - O(n)"""
        course_node = self._find_node(self.root, [course_name])

        if not course_node:
            return []

        return self._get_all_files(course_node)

    def _get_all_files(self, node):
        """Recursively get all files under a node"""
        files = []

        if node.node_type == "file":
            files.append(node.data)

        for child in node.children:
            files.extend(self._get_all_files(child))

        return files

    def get_tree_structure(self):
        """Get entire tree structure as nested dict - O(n)"""
        return self._node_to_dict(self.root)

    def _node_to_dict(self, node):
        """Convert node to dictionary"""
        result = {
            'name': node.data,
            'type': node.node_type,
            'children': []
        }

        for child in node.children:
            result['children'].append(self._node_to_dict(child))

        return result

    def search(self, resource_name):
        """Search for resource - O(n)"""
        return self._search_helper(self.root, resource_name)

    def _search_helper(self, node, target):
        """DFS search for resource"""
        if node.data == target:
            return self._get_path(node)

        for child in node.children:
            result = self._search_helper(child, target)
            if result:
                return result

        return None

    def _get_path(self, node):
        """Get path from root to node"""
        path = []
        current = node

        while current:
            path.insert(0, current.data)
            current = current.parent

        return path

    def get_all_courses(self):
        """Get all course folders - O(1)"""
        return [child.data for child in self.root.children if child.node_type == "folder"]

    def to_dict(self):
        """Convert tree to dictionary for JSON storage"""
        return self.get_tree_structure()

    @classmethod
    def from_dict(cls, data):
        """Create tree from dictionary"""
        tree = cls(data.get('name', 'Resources'))
        tree.root = cls._dict_to_node(data)
        return tree

    @classmethod
    def _dict_to_node(cls, data):
        """Convert dictionary to node"""
        node = TreeNode(data['name'], data['type'])

        for child_data in data.get('children', []):
            child_node = cls._dict_to_node(child_data)
            node.add_child(child_node)

        return node

    def __str__(self):
        """String representation"""
        return f"Tree(root={self.root.data}, courses={len(self.root.children)})"


class BinarySearchTree:
    """
    Binary Search Tree (Optional - for sorted data)
    Can be used for sorted resource indexing
    """

    class BSTNode:
        def __init__(self, key, value):
            self.key = key
            self.value = value
            self.left = None
            self.right = None

    def __init__(self):
        self.root = None

    def insert(self, key, value):
        """Insert key-value pair - O(log n) average"""
        if not self.root:
            self.root = self.BSTNode(key, value)
            return True

        self._insert_helper(self.root, key, value)
        return True

    def _insert_helper(self, node, key, value):
        """Recursive insert helper"""
        if key < node.key:
            if node.left is None:
                node.left = self.BSTNode(key, value)
            else:
                self._insert_helper(node.left, key, value)
        elif key > node.key:
            if node.right is None:
                node.right = self.BSTNode(key, value)
            else:
                self._insert_helper(node.right, key, value)
        else:
            node.value = value  # Update if key exists

    def search(self, key):
        """Search for key - O(log n) average"""
        return self._search_helper(self.root, key)

    def _search_helper(self, node, key):
        """Recursive search helper"""
        if node is None or node.key == key:
            return node.value if node else None

        if key < node.key:
            return self._search_helper(node.left, key)
        return self._search_helper(node.right, key)

    def inorder(self):
        """Inorder traversal - O(n)"""
        result = []
        self._inorder_helper(self.root, result)
        return result

    def _inorder_helper(self, node, result):
        """Recursive inorder helper"""
        if node:
            self._inorder_helper(node.left, result)
            result.append((node.key, node.value))
            self._inorder_helper(node.right, result)