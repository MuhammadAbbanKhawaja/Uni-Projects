import heapq
from datetime import datetime


class PriorityQueue:
    """
    Priority Queue implementation using Min Heap
    Used for: Session Scheduler (earliest sessions have highest priority)
    Time Complexity: O(log n) for insert and extract_min
    """

    def __init__(self):
        self.heap = []
        self.counter = 0  # To handle items with same priority

    def insert(self, item, priority=None):
        """
        Insert session with priority - O(log n)
        priority: timestamp or datetime object (earlier = higher priority)
        """
        if priority is None:
            priority = datetime.now().timestamp()

        # Convert datetime to timestamp if needed
        if isinstance(priority, datetime):
            priority = priority.timestamp()

        # Push tuple: (priority, counter, item)
        # counter ensures FIFO for same priority
        heapq.heappush(self.heap, (priority, self.counter, item))
        self.counter += 1
        return True

    def extract_min(self):
        """Extract session with highest priority (earliest time) - O(log n)"""
        if self.is_empty():
            return None

        priority, _, item = heapq.heappop(self.heap)
        return item

    def peek(self):
        """View next session without removing - O(1)"""
        if self.is_empty():
            return None

        priority, _, item = self.heap[0]
        return item

    def is_empty(self):
        """Check if queue is empty - O(1)"""
        return len(self.heap) == 0

    def size(self):
        """Get number of sessions - O(1)"""
        return len(self.heap)

    def get_all(self):
        """Get all sessions sorted by priority - O(n log n)"""
        return [item for _, _, item in sorted(self.heap)]

    def get_upcoming(self, n=5):
        """Get next n upcoming sessions - O(n log n)"""
        sorted_items = self.get_all()
        return sorted_items[:n]

    def clear(self):
        """Remove all sessions - O(1)"""
        self.heap = []
        self.counter = 0

    def to_list(self):
        """Convert to list for JSON storage"""
        return [{'priority': p, 'item': item} for p, _, item in self.heap]

    @classmethod
    def from_list(cls, data):
        """Create priority queue from list"""
        pq = cls()
        for entry in data:
            pq.insert(entry['item'], entry['priority'])
        return pq

    def __str__(self):
        """String representation"""
        return f"PriorityQueue(size={len(self.heap)})"

    def __len__(self):
        """Allow len(priority_queue)"""
        return len(self.heap)