class Node:
    """Node for Linked List"""

    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    """
    Singly Linked List implementation
    Used for: Recent resources (easy insertion at head)
    Time Complexity: O(1) for insert at head, O(n) for search
    """

    def __init__(self):
        self.head = None
        self.size = 0

    def insert_at_head(self, data):
        """Insert resource at beginning - O(1)"""
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node
        self.size += 1
        return True

    def insert_at_tail(self, data):
        """Insert resource at end - O(n)"""
        new_node = Node(data)

        if not self.head:
            self.head = new_node
            self.size += 1
            return True

        current = self.head
        while current.next:
            current = current.next

        current.next = new_node
        self.size += 1
        return True

    def delete(self, data):
        """Delete resource - O(n)"""
        if not self.head:
            return False

        # If head needs to be deleted
        if self.head.data == data:
            self.head = self.head.next
            self.size -= 1
            return True

        # Search for node to delete
        current = self.head
        while current.next:
            if current.next.data == data:
                current.next = current.next.next
                self.size -= 1
                return True
            current = current.next

        return False

    def search(self, data):
        """Search for resource - O(n)"""
        current = self.head
        while current:
            if current.data == data:
                return True
            current = current.next
        return False

    def get_all(self):
        """Get all resources as list - O(n)"""
        result = []
        current = self.head
        while current:
            result.append(current.data)
            current = current.next
        return result

    def get_recent(self, n=10):
        """Get n most recent resources - O(n)"""
        result = []
        current = self.head
        count = 0

        while current and count < n:
            result.append(current.data)
            current = current.next
            count += 1

        return result

    def is_empty(self):
        """Check if list is empty - O(1)"""
        return self.head is None

    def get_size(self):
        """Get size - O(1)"""
        return self.size

    def clear(self):
        """Clear all resources - O(1)"""
        self.head = None
        self.size = 0

    def to_list(self):
        """Convert to list for JSON storage"""
        return self.get_all()

    @classmethod
    def from_list(cls, data):
        """Create linked list from list"""
        ll = cls()
        # Insert in reverse to maintain order
        for item in reversed(data):
            ll.insert_at_head(item)
        return ll

    def __str__(self):
        """String representation"""
        items = self.get_all()
        return f"LinkedList(size={self.size}, items={items[:3]}...)" if len(
            items) > 3 else f"LinkedList(size={self.size}, items={items})"

    def __len__(self):
        """Allow len(linked_list)"""
        return self.size

    def __contains__(self, item):
        """Allow 'item in linked_list'"""
        return self.search(item)


class DoublyLinkedListNode:
    """Node for Doubly Linked List"""

    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None


class DoublyLinkedList:
    """
    Doubly Linked List (if needed for bidirectional traversal)
    """

    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def insert_at_head(self, data):
        """Insert at beginning - O(1)"""
        new_node = DoublyLinkedListNode(data)

        if not self.head:
            self.head = self.tail = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node

        self.size += 1
        return True

    def insert_at_tail(self, data):
        """Insert at end - O(1)"""
        new_node = DoublyLinkedListNode(data)

        if not self.tail:
            self.head = self.tail = new_node
        else:
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node

        self.size += 1
        return True

    def get_all(self):
        """Get all items - O(n)"""
        result = []
        current = self.head
        while current:
            result.append(current.data)
            current = current.next
        return result