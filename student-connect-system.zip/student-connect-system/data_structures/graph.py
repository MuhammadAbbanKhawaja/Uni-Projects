class Graph:
    """
    Graph implementation using Adjacency List
    Nodes: Students (identified by roll number)
    Edges: Connections between students (shared courses, friendships)
    """

    def __init__(self):
        self.adjacency_list = {}
        self.edge_weights = {}  # Store edge metadata (e.g., shared courses)

    def add_vertex(self, vertex):
        """Add a student node - O(1)"""
        if vertex not in self.adjacency_list:
            self.adjacency_list[vertex] = []
            return True
        return False

    def add_edge(self, vertex1, vertex2, weight=None):
        """
        Add connection between two students - O(1)
        weight: metadata like shared courses count, connection type
        """
        # Ensure both vertices exist
        self.add_vertex(vertex1)
        self.add_vertex(vertex2)

        # Add undirected edge
        if vertex2 not in self.adjacency_list[vertex1]:
            self.adjacency_list[vertex1].append(vertex2)

        if vertex1 not in self.adjacency_list[vertex2]:
            self.adjacency_list[vertex2].append(vertex1)

        # Store edge weight/metadata
        if weight:
            edge_key = tuple(sorted([vertex1, vertex2]))
            self.edge_weights[edge_key] = weight

        return True

    def remove_edge(self, vertex1, vertex2):
        """Remove connection - O(V) where V is vertex degree"""
        if vertex1 in self.adjacency_list and vertex2 in self.adjacency_list[vertex1]:
            self.adjacency_list[vertex1].remove(vertex2)

        if vertex2 in self.adjacency_list and vertex1 in self.adjacency_list[vertex2]:
            self.adjacency_list[vertex2].remove(vertex1)

        # Remove edge weight
        edge_key = tuple(sorted([vertex1, vertex2]))
        if edge_key in self.edge_weights:
            del self.edge_weights[edge_key]

        return True

    def get_neighbors(self, vertex):
        """Get all connections of a student - O(1)"""
        return self.adjacency_list.get(vertex, [])

    def get_edge_weight(self, vertex1, vertex2):
        """Get connection metadata - O(1)"""
        edge_key = tuple(sorted([vertex1, vertex2]))
        return self.edge_weights.get(edge_key)

    def has_edge(self, vertex1, vertex2):
        """Check if connection exists - O(V)"""
        return vertex2 in self.adjacency_list.get(vertex1, [])

    def get_all_vertices(self):
        """Get all students - O(1)"""
        return list(self.adjacency_list.keys())

    def get_all_edges(self):
        """Get all connections - O(V + E)"""
        edges = []
        visited = set()

        for vertex in self.adjacency_list:
            for neighbor in self.adjacency_list[vertex]:
                edge = tuple(sorted([vertex, neighbor]))
                if edge not in visited:
                    visited.add(edge)
                    weight = self.get_edge_weight(vertex, neighbor)
                    edges.append({
                        'from': vertex,
                        'to': neighbor,
                        'weight': weight
                    })

        return edges

    def degree(self, vertex):
        """Get connection count of a student - O(1)"""
        return len(self.adjacency_list.get(vertex, []))

    def to_dict(self):
        """Convert graph to dictionary format for JSON storage"""
        return {
            'adjacency_list': self.adjacency_list,
            'edge_weights': {str(k): v for k, v in self.edge_weights.items()}
        }

    @classmethod
    def from_dict(cls, data):
        """Create graph from dictionary"""
        graph = cls()
        graph.adjacency_list = data.get('adjacency_list', {})

        # Convert edge keys back to tuples
        edge_weights = data.get('edge_weights', {})
        for key, value in edge_weights.items():
            tuple_key = eval(key)  # Convert string back to tuple
            graph.edge_weights[tuple_key] = value

        return graph

    def __str__(self):
        """String representation"""
        return f"Graph(vertices={len(self.adjacency_list)}, edges={len(self.edge_weights)})"