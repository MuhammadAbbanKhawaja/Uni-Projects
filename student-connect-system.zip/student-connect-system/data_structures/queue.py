class Queue:
    """
    Queue implementation using Python list
    Used for: Study Group join requests (FIFO - First In First Out)
    Time Complexity: O(1) for enqueue and dequeue
    """

    def __init__(self):
        self.items = []

    def enqueue(self, item):
        """Add join request to queue - O(1)"""
        self.items.append(item)
        return True

    def dequeue(self):
        """Process next join request - O(n) due to list.pop(0)"""
        if self.is_empty():
            return None
        return self.items.pop(0)

    def front(self):
        """View next request without removing - O(1)"""
        if self.is_empty():
            return None
        return self.items[0]

    def is_empty(self):
        """Check if queue is empty - O(1)"""
        return len(self.items) == 0

    def size(self):
        """Get number of pending requests - O(1)"""
        return len(self.items)

    def get_all(self):
        """Get all pending requests - O(1)"""
        return self.items.copy()

    def clear(self):
        """Clear all requests - O(1)"""
        self.items = []

    def to_list(self):
        """Convert to list for JSON storage"""
        return self.items

    @classmethod
    def from_list(cls, data):
        """Create queue from list"""
        queue = cls()
        queue.items = data
        return queue

    def __str__(self):
        """String representation"""
        return f"Queue(size={len(self.items)})"

    def __len__(self):
        """Allow len(queue)"""
        return len(self.items)

    def __contains__(self, item):
        """Allow 'item in queue'"""
        return item in self.items


class CircularQueue:
    """
    Circular Queue implementation with fixed size
    More efficient than regular queue for fixed capacity scenarios
    """

    def __init__(self, capacity=10):
        self.capacity = capacity
        self.items = [None] * capacity
        self.front_idx = 0
        self.rear_idx = -1
        self.count = 0

    def enqueue(self, item):
        """Add item - O(1)"""
        if self.is_full():
            return False

        self.rear_idx = (self.rear_idx + 1) % self.capacity
        self.items[self.rear_idx] = item
        self.count += 1
        return True

    def dequeue(self):
        """Remove item - O(1)"""
        if self.is_empty():
            return None

        item = self.items[self.front_idx]
        self.items[self.front_idx] = None
        self.front_idx = (self.front_idx + 1) % self.capacity
        self.count -= 1
        return item

    def front(self):
        """View front item - O(1)"""
        if self.is_empty():
            return None
        return self.items[self.front_idx]

    def is_empty(self):
        """Check if empty - O(1)"""
        return self.count == 0

    def is_full(self):
        """Check if full - O(1)"""
        return self.count == self.capacity

    def size(self):
        """Get size - O(1)"""
        return self.count

    def __str__(self):
        """String representation"""
        return f"CircularQueue(size={self.count}/{self.capacity})"