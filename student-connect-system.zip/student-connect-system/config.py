import os


class Config:
    SECRET_KEY = 'your-secret-key-here-change-in-production'
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    DATA_DIR = os.path.join(BASE_DIR, 'data')

    # Ensure data directory exists
    os.makedirs(DATA_DIR, exist_ok=True)