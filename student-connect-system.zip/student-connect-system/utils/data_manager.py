import json
import os
from data_structures.hash_map import HashMap
from data_structures.graph import Graph
from data_structures.priority_queue import PriorityQueue
from data_structures.linked_list import LinkedList
from data_structures.tree import Tree
from models.student import Student
from models.study_group import StudyGroup
from models.session import StudySession
from models.resources import Resource


class DataManager:
    """Manages all data persistence for the application"""

    def __init__(self, data_dir='data'):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)

        # File paths
        self.students_file = os.path.join(data_dir, 'students.json')
        self.graph_file = os.path.join(data_dir, 'graph.json')
        self.groups_file = os.path.join(data_dir, 'groups.json')
        self.sessions_file = os.path.join(data_dir, 'sessions.json')
        self.resources_file = os.path.join(data_dir, 'resources.json')

    # ==================== STUDENTS ====================

    def save_students(self, student_hashmap):
        """Save students HashMap to JSON"""
        students_list = student_hashmap.get_all()
        with open(self.students_file, 'w') as f:
            json.dump(students_list, f, indent=2)
        return True

    def load_students(self):
        """Load students from JSON into HashMap"""
        student_hashmap = HashMap()

        if os.path.exists(self.students_file):
            with open(self.students_file, 'r') as f:
                students_list = json.load(f)

            for student_data in students_list:
                roll = student_data.get('roll_number')
                student_hashmap.insert(roll, student_data)

        return student_hashmap

    # ==================== GRAPH ====================

    def save_graph(self, graph):
        """Save graph to JSON"""
        graph_data = graph.to_dict()
        with open(self.graph_file, 'w') as f:
            json.dump(graph_data, f, indent=2)
        return True

    def load_graph(self):
        """Load graph from JSON"""
        if os.path.exists(self.graph_file):
            with open(self.graph_file, 'r') as f:
                graph_data = json.load(f)
            return Graph.from_dict(graph_data)

        return Graph()

    # ==================== STUDY GROUPS ====================

    def save_groups(self, groups_list):
        """Save study groups to JSON"""
        groups_data = [group.to_dict() for group in groups_list]
        with open(self.groups_file, 'w') as f:
            json.dump(groups_data, f, indent=2)
        return True

    def load_groups(self):
        """Load study groups from JSON"""
        if os.path.exists(self.groups_file):
            with open(self.groups_file, 'r') as f:
                groups_data = json.load(f)
            return [StudyGroup.from_dict(g) for g in groups_data]

        return []

    # ==================== SESSIONS ====================

    def save_sessions(self, sessions_list):
        """Save study sessions to JSON"""
        sessions_data = [session.to_dict() for session in sessions_list]
        with open(self.sessions_file, 'w') as f:
            json.dump(sessions_data, f, indent=2)
        return True

    def load_sessions(self):
        """Load study sessions from JSON"""
        if os.path.exists(self.sessions_file):
            with open(self.sessions_file, 'r') as f:
                sessions_data = json.load(f)
            return [StudySession.from_dict(s) for s in sessions_data]

        return []

    def load_sessions_to_priority_queue(self):
        """Load sessions into priority queue ordered by datetime"""
        sessions = self.load_sessions()
        pq = PriorityQueue()

        for session in sessions:
            if session.is_upcoming():
                pq.insert(session.to_dict(), session.get_timestamp())

        return pq

    # ==================== RESOURCES ====================

    def save_resources(self, resources_list):
        """Save resources to JSON"""
        resources_data = [resource.to_dict() for resource in resources_list]
        with open(self.resources_file, 'w') as f:
            json.dump(resources_data, f, indent=2)
        return True

    def load_resources(self):
        """Load resources from JSON"""
        if os.path.exists(self.resources_file):
            with open(self.resources_file, 'r') as f:
                resources_data = json.load(f)
            return [Resource.from_dict(r) for r in resources_data]

        return []

    def load_resources_to_linked_list(self):
        """Load resources into linked list (most recent first)"""
        resources = self.load_resources()
        ll = LinkedList()

        # Sort by upload date (most recent first)
        resources.sort(key=lambda r: r.uploaded_at, reverse=True)

        for resource in resources:
            ll.insert_at_tail(resource.to_dict())

        return ll

    # ==================== TREE (RESOURCE ORGANIZATION) ====================

    def build_resource_tree(self):
        """Build tree structure for resources organized by course"""
        resources = self.load_resources()
        tree = Tree("All Resources")

        # Organize by course
        courses = {}
        for resource in resources:
            course = resource.course
            if course not in courses:
                courses[course] = []
            courses[course].append(resource)

        # Add to tree
        for course, course_resources in courses.items():
            tree.add_node([], course, "folder")

            for resource in course_resources:
                tree.add_node([course], resource.title, "file")

        return tree

    # ==================== HELPER METHODS ====================

    def clear_all_data(self):
        """Clear all data files (for testing)"""
        for file_path in [self.students_file, self.graph_file, self.groups_file,
                          self.sessions_file, self.resources_file]:
            if os.path.exists(file_path):
                os.remove(file_path)
        return True

    def data_exists(self):
        """Check if any data files exist"""
        return any(os.path.exists(f) for f in [self.students_file, self.graph_file,
                                               self.groups_file, self.sessions_file,
                                               self.resources_file])