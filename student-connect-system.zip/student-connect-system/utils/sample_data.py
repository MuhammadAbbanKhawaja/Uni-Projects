from models.student import Student
from models.study_group import StudyGroup
from models.session import StudySession
from models.resources import Resource
from data_structures.hash_map import HashMap
from data_structures.graph import Graph
from datetime import datetime, timedelta
import random


def generate_sample_students():
    """Generate sample students for demonstration"""

    departments = ['CS', 'SE', 'AI', 'DS', 'CYS']

    # Common courses by department
    courses_by_dept = {
        'CS': ['Data Structures', 'Algorithms', 'Database Systems', 'Operating Systems', 'Computer Networks'],
        'SE': ['Software Engineering', 'Web Development', 'Mobile App Development', 'Data Structures',
               'Database Systems'],
        'AI': ['Machine Learning', 'Deep Learning', 'Data Mining', 'Neural Networks', 'Python Programming'],
        'DS': ['Statistics', 'Data Analysis', 'Machine Learning', 'Big Data', 'Python Programming'],
        'CYS': ['Cryptography', 'Network Security', 'Ethical Hacking', 'Computer Networks', 'Operating Systems']
    }

    skills_pool = [
        'Python', 'Java', 'C++', 'JavaScript', 'React', 'Node.js',
        'Machine Learning', 'Data Analysis', 'Web Development', 'Mobile Development',
        'Database Design', 'System Design', 'Problem Solving', 'Git'
    ]

    students_data = [
        {'name': 'Ali Ahmed', 'roll': '2021-CS-001', 'dept': 'CS', 'sem': 5, 'email': 'ali.ahmed@uni.edu.pk'},
        {'name': 'Fatima Khan', 'roll': '2021-CS-002', 'dept': 'CS', 'sem': 5, 'email': 'fatima.khan@uni.edu.pk'},
        {'name': 'Hassan Ali', 'roll': '2021-SE-001', 'dept': 'SE', 'sem': 5, 'email': 'hassan.ali@uni.edu.pk'},
        {'name': 'Ayesha Malik', 'roll': '2021-SE-002', 'dept': 'SE', 'sem': 5, 'email': 'ayesha.malik@uni.edu.pk'},
        {'name': 'Usman Tariq', 'roll': '2022-CS-001', 'dept': 'CS', 'sem': 3, 'email': 'usman.tariq@uni.edu.pk'},
        {'name': 'Sara Noor', 'roll': '2022-CS-002', 'dept': 'CS', 'sem': 3, 'email': 'sara.noor@uni.edu.pk'},
        {'name': 'Ahmed Raza', 'roll': '2022-AI-001', 'dept': 'AI', 'sem': 3, 'email': 'ahmed.raza@uni.edu.pk'},
        {'name': 'Zainab Hussain', 'roll': '2022-AI-002', 'dept': 'AI', 'sem': 3, 'email': 'zainab.hussain@uni.edu.pk'},
        {'name': 'Bilal Sheikh', 'roll': '2021-AI-001', 'dept': 'AI', 'sem': 5, 'email': 'bilal.sheikh@uni.edu.pk'},
        {'name': 'Maryam Siddiqui', 'roll': '2021-DS-001', 'dept': 'DS', 'sem': 5,
         'email': 'maryam.siddiqui@uni.edu.pk'},
        {'name': 'Hamza Iqbal', 'roll': '2022-DS-001', 'dept': 'DS', 'sem': 3, 'email': 'hamza.iqbal@uni.edu.pk'},
        {'name': 'Hira Aslam', 'roll': '2022-CYS-001', 'dept': 'CYS', 'sem': 3, 'email': 'hira.aslam@uni.edu.pk'},
        {'name': 'Faisal Mahmood', 'roll': '2021-CYS-001', 'dept': 'CYS', 'sem': 5,
         'email': 'faisal.mahmood@uni.edu.pk'},
        {'name': 'Aiman Riaz', 'roll': '2021-CS-003', 'dept': 'CS', 'sem': 5, 'email': 'aiman.riaz@uni.edu.pk'},
        {'name': 'Omer Farooq', 'roll': '2022-SE-003', 'dept': 'SE', 'sem': 3, 'email': 'omer.farooq@uni.edu.pk'},
    ]

    student_hashmap = HashMap()

    for data in students_data:
        dept_courses = courses_by_dept[data['dept']]
        selected_courses = random.sample(dept_courses, min(4, len(dept_courses)))
        selected_skills = random.sample(skills_pool, random.randint(3, 6))

        student = Student(
            roll_number=data['roll'],
            name=data['name'],
            email=data['email'],
            password='password123',  # Default password for demo
            department=data['dept'],
            semester=data['sem'],
            courses=selected_courses,
            skills=selected_skills
        )
        student.cgpa = round(random.uniform(2.5, 4.0), 2)

        student_hashmap.insert(data['roll'], student.to_dict())

    return student_hashmap


def generate_sample_graph(student_hashmap):
    """Generate graph connections based on shared courses"""
    graph = Graph()
    students = student_hashmap.get_all()

    # Add all students as vertices
    for student in students:
        graph.add_vertex(student['roll_number'])

    # Create connections based on shared courses
    for i, student1 in enumerate(students):
        for student2 in students[i + 1:]:
            courses1 = set(student1['courses'])
            courses2 = set(student2['courses'])
            shared_courses = courses1 & courses2

            # Add edge if they share at least 1 course
            if shared_courses:
                graph.add_edge(
                    student1['roll_number'],
                    student2['roll_number'],
                    weight={'shared_courses': list(shared_courses)}
                )

    return graph


def generate_sample_groups(students):
    """Generate sample study groups"""
    groups = []

    courses = ['Data Structures', 'Machine Learning', 'Web Development',
               'Database Systems', 'Computer Networks']

    for i, course in enumerate(courses):
        # Find students taking this course
        eligible_students = [s for s in students if course in s.get('courses', [])]

        if eligible_students:
            creator = eligible_students[0]
            group = StudyGroup(
                name=f"{course} Study Group",
                course=course,
                creator_roll=creator['roll_number'],
                description=f"Let's master {course} together!",
                max_members=8
            )

            # Add some members
            for student in eligible_students[1:min(4, len(eligible_students))]:
                group.add_member(student['roll_number'])

            groups.append(group)

    return groups


def generate_sample_sessions(students):
    """Generate sample study sessions"""
    sessions = []

    courses = ['Data Structures', 'Machine Learning', 'Web Development']
    locations = ['Library Room 101', 'Computer Lab 2', 'Cafeteria Study Area', 'Online - Zoom']

    for i, course in enumerate(courses):
        eligible_students = [s for s in students if course in s.get('courses', [])]

        if eligible_students:
            organizer = eligible_students[0]

            # Create future session
            future_date = datetime.now() + timedelta(days=i + 2)

            session = StudySession(
                title=f"{course} Group Study",
                course=course,
                organizer_roll=organizer['roll_number'],
                date=future_date.strftime("%Y-%m-%d"),
                time="15:00",
                location=locations[i],
                description=f"Weekly study session for {course}",
                max_participants=6
            )

            # Add some participants
            for student in eligible_students[1:min(3, len(eligible_students))]:
                session.join_session(student['roll_number'])

            sessions.append(session)

    return sessions


def generate_sample_resources(students):
    """Generate sample resources"""
    resources = []

    resource_data = [
        {'title': 'Data Structures Notes', 'course': 'Data Structures', 'type': 'notes',
         'url': 'https://example.com/ds-notes.pdf', 'tags': ['graphs', 'trees', 'algorithms']},
        {'title': 'ML Tutorial Video', 'course': 'Machine Learning', 'type': 'video',
         'url': 'https://youtube.com/watch?v=example', 'tags': ['neural networks', 'python']},
        {'title': 'React Documentation', 'course': 'Web Development', 'type': 'link',
         'url': 'https://react.dev/', 'tags': ['react', 'javascript', 'frontend']},
        {'title': 'Database Design Guide', 'course': 'Database Systems', 'type': 'document',
         'url': 'https://example.com/db-guide.pdf', 'tags': ['sql', 'normalization']},
        {'title': 'Network Protocol Overview', 'course': 'Computer Networks', 'type': 'notes',
         'url': 'https://example.com/networks.pdf', 'tags': ['tcp', 'ip', 'protocols']},
    ]

    for i, data in enumerate(resource_data):
        # Pick random student as uploader
        uploader = students[i % len(students)]

        resource = Resource(
            title=data['title'],
            course=data['course'],
            uploader_roll=uploader['roll_number'],
            resource_type=data['type'],
            url=data['url'],
            tags=data['tags']
        )
        resource.views = random.randint(10, 100)

        # Add some random likes
        for _ in range(random.randint(2, 8)):
            random_student = random.choice(students)
            resource.like(random_student['roll_number'])

        resources.append(resource)

    return resources


def initialize_sample_data(data_manager):
    """Initialize all sample data and save to files"""
    print("Generating sample data...")

    # Generate students
    student_hashmap = generate_sample_students()
    students = student_hashmap.get_all()
    print(f"✓ Generated {len(students)} students")

    # Generate graph
    graph = generate_sample_graph(student_hashmap)
    print(f"✓ Generated graph with {len(graph.get_all_edges())} connections")

    # Generate groups
    groups = generate_sample_groups(students)
    print(f"✓ Generated {len(groups)} study groups")

    # Generate sessions
    sessions = generate_sample_sessions(students)
    print(f"✓ Generated {len(sessions)} study sessions")

    # Generate resources
    resources = generate_sample_resources(students)
    print(f"✓ Generated {len(resources)} resources")

    # Save all data
    data_manager.save_students(student_hashmap)
    data_manager.save_graph(graph)
    data_manager.save_groups(groups)
    data_manager.save_sessions(sessions)
    data_manager.save_resources(resources)

    print("\n✅ Sample data initialized successfully!")
    print("\nDemo Login Credentials:")
    print("Roll Number: 2021-CS-001")
    print("Password: password123")

    return True